"""PPV-Lite: budget-constrained detector scheduling with temporal propagation.

Reference implementation of the online components described in the paper:
pre-inference features (Eqs. 7-9), the token-bucket controller (Eq. 10,
Proposition 1), and sparse Lucas-Kanade box propagation (Section 3.5).
The experiment pipeline in ``experiments/ppv_lite_pipeline.py`` uses the
same logic; this module packages it for reuse.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional, Sequence

import cv2
import numpy as np

SMALL = (80, 45)          # thumbnail size (width, height)
FLOW_SCALE = 0.25         # propagation resolution
LK_PARAMS = dict(winSize=(21, 21), maxLevel=3,
                 criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, 0.01))
FEATURES = ["gap", "entropy", "brightness_change", "mean_confidence_previous", "scene_diff"]


# --------------------------------------------------------------------- features
def entropy(small: np.ndarray) -> float:
    """Shannon entropy of the 32-bin intensity histogram of a thumbnail."""
    h = cv2.calcHist([small], [0], None, [32], [0, 256]).ravel()
    p = h / h.sum() if h.sum() > 0 else h
    p = p[p > 0]
    return float(-(p * np.log2(p)).sum()) if len(p) else 0.0


def features(t: int, k: int, small_t: np.ndarray, small_k: np.ndarray, conf_k: np.ndarray) -> list:
    """Five pre-inference features X_t (gap, entropy, brightness change,
    previous mean confidence, scene difference)."""
    return [t - k,
            entropy(small_t),
            float(small_t.mean() / 255.0 - small_k.mean() / 255.0),
            float(conf_k.mean()) if len(conf_k) else 0.0,
            float(np.abs(small_t.astype(np.float32) - small_k.astype(np.float32)).mean() / 255.0)]


# --------------------------------------------------------------------- classifier
class FastTree:
    """Fast single-row prediction for a fitted scikit-learn DecisionTreeClassifier."""

    def __init__(self, clf):
        t = clf.tree_
        self.l, self.r, self.f, self.th = t.children_left, t.children_right, t.feature, t.threshold
        v = t.value[:, 0, :]
        self.p = v[:, 1] / np.maximum(v.sum(1), 1e-12)

    def __call__(self, x: Sequence[float]) -> float:
        n = 0
        while self.l[n] != -1:
            n = self.l[n] if x[self.f[n]] <= self.th[n] else self.r[n]
        return float(self.p[n])


# --------------------------------------------------------------------- propagation
def propagate(flow_k: np.ndarray, flow_t: np.ndarray, boxes: np.ndarray, conf: np.ndarray,
              width: int, height: int):
    """Move boxes from frame k to frame t by the median displacement of their
    centre and four corners (quarter-resolution grayscale inputs)."""
    if len(boxes) == 0:
        return boxes, conf
    s = FLOW_SCALE
    x1, y1, x2, y2 = boxes[:, 0], boxes[:, 1], boxes[:, 2], boxes[:, 3]
    pts = np.stack([np.stack([x1, y1], 1), np.stack([x2, y1], 1), np.stack([x1, y2], 1),
                    np.stack([x2, y2], 1), np.stack([(x1 + x2) / 2, (y1 + y2) / 2], 1)], 1)
    p0 = (pts.reshape(-1, 2) * s).astype(np.float32).reshape(-1, 1, 2)
    p1, st, _ = cv2.calcOpticalFlowPyrLK(flow_k, flow_t, p0, None, **LK_PARAMS)
    if p1 is None or st is None:
        return boxes, conf
    disp = ((p1 - p0).reshape(-1, 5, 2)) / s
    ok = st.reshape(-1, 5) > 0
    ob, oc = [], []
    for i, b in enumerate(boxes):
        if ok[i].sum() < 3:
            ob.append(b); oc.append(conf[i]); continue
        dx = float(np.median(disp[i, ok[i], 0])); dy = float(np.median(disp[i, ok[i], 1]))
        nb = [min(max(b[0] + dx, 0), width - 1), min(max(b[1] + dy, 0), height - 1),
              min(max(b[2] + dx, 0), width - 1), min(max(b[3] + dy, 0), height - 1)]
        if nb[2] > nb[0] and nb[3] > nb[1]:
            ob.append(nb); oc.append(conf[i])
    return np.asarray(ob, np.float32).reshape(-1, 4), np.asarray(oc, np.float32)


# --------------------------------------------------------------------- scheduler
@dataclass
class PPVLite:
    """Online PPV-Lite scheduler.

    detector(image) -> (boxes[N,4] float32 xyxy, conf[N] float32)
    tree(features) -> predicted benefit p_hat in [0, 1]
    rho: target call rate; tau: decision threshold; cap: bucket cap C (>= 1).
    """
    detector: Callable[[np.ndarray], tuple]
    tree: Callable[[Sequence[float]], float]
    rho: float = 0.25
    tau: float = 0.6
    cap: float = 1.5
    credit: float = 0.0
    k: int = -1
    _state: dict = field(default_factory=dict)

    def reset(self, first_image: np.ndarray, t0: int = 0):
        """Run the detector once to initialise the state (frame t0)."""
        g = cv2.cvtColor(first_image, cv2.COLOR_BGR2GRAY)
        b, c = self.detector(first_image)
        self._state = {"boxes": b, "conf": c,
                       "flow": cv2.resize(g, None, fx=FLOW_SCALE, fy=FLOW_SCALE, interpolation=cv2.INTER_AREA),
                       "small": cv2.resize(g, SMALL, interpolation=cv2.INTER_AREA),
                       "hw": first_image.shape[:2]}
        self.k, self.credit = t0, 0.0
        return b, c

    def step(self, image: np.ndarray, t: int):
        """Process frame t; returns (boxes, conf, ran_detector)."""
        g = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        flow_t = cv2.resize(g, None, fx=FLOW_SCALE, fy=FLOW_SCALE, interpolation=cv2.INTER_AREA)
        small_t = None
        self.credit += self.rho
        run = False
        if self.credit >= 1.0:
            if self.credit >= self.cap:
                run = True
            else:
                small_t = cv2.resize(g, SMALL, interpolation=cv2.INTER_AREA)
                x = features(t, self.k, small_t, self._state["small"], self._state["conf"])
                run = self.tree(x) >= self.tau
        if run:
            self.credit -= 1.0
            b, c = self.detector(image)
            if small_t is None:
                small_t = cv2.resize(g, SMALL, interpolation=cv2.INTER_AREA)
            self._state.update(boxes=b, conf=c, flow=flow_t, small=small_t)
            self.k = t
            return b, c, True
        h, w = self._state["hw"]
        b, c = propagate(self._state["flow"], flow_t, self._state["boxes"], self._state["conf"], w, h)
        return b, c, False


def periodic_schedule(lo: int, hi: int, n: int) -> list:
    """n detector calls spread evenly over frames lo..hi."""
    if n <= 0:
        return []
    L = hi - lo + 1
    return sorted(set(int(round(lo + (i + 1) * L / n - 1)) for i in range(n)))
