"""Checks Proposition 1 (call-count bound and maximum gap) and basic propagation."""
import math
import numpy as np
from ppv_lite import PPVLite


def fake_detector(img):
    return np.array([[100, 100, 200, 300]], np.float32), np.array([0.9], np.float32)


def test_call_count_bound():
    rng = np.random.default_rng(0)
    img = np.zeros((360, 640, 3), np.uint8)
    for rho in [1/3, 1/4, 1/5, 1/6, 1/8, 1/10]:
        for cap in [1.5, 2.0, 3.0]:
            s = PPVLite(fake_detector, lambda x: rng.random(), rho=rho, tau=0.5, cap=cap)
            s.reset(img, 0)
            T, calls, last, gaps = 500, 0, 0, []
            for t in range(1, T + 1):
                _, _, ran = s.step(img, t)
                if ran:
                    calls += 1; gaps.append(t - last); last = t
            assert rho * T - cap < calls <= rho * T + 1e-9
            assert max(gaps) <= math.ceil(cap / rho) + 1   # +1 tolerates float accumulation


def test_propagation_shape():
    img = np.zeros((360, 640, 3), np.uint8)
    s = PPVLite(fake_detector, lambda x: 0.0, rho=0.1, tau=0.5, cap=1.5)
    s.reset(img, 0)
    b, c, ran = s.step(img, 1)
    assert not ran and b.shape[1] == 4 and len(b) == len(c)
