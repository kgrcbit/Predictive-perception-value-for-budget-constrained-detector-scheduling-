# PPV-Lite: budget-constrained detector scheduling with temporal propagation

Code, results, and figure scripts for the paper

> G. R. Kommu and R. R. Ramisetty, *Predictive perception value for budget-constrained detector scheduling in pedestrian video with temporal propagation* (under review).

PPV-Lite decides on which video frames to run an object detector when the number of detector calls is fixed. A depth-3 decision tree predicts, from five inexpensive pre-inference features, whether a fresh detection would beat propagating the previous boxes with optical flow (the sign of the *predictive perception value*, PPV). A token-bucket controller keeps the number of calls within one cap of the budget. Skipped frames are served by sparse Lucas-Kanade propagation.

## Repository layout

| Path | Contents |
|---|---|
| `ppv_lite/` | Reusable implementation: features, token-bucket scheduler, Lucas-Kanade propagation, fast tree inference |
| `tests/` | Checks of the call-count bound (Proposition 1) and propagation |
| `experiments/ppv_lite_pipeline.py` | Complete experiment pipeline (single Kaggle cell): detector caches, labels, leave-one-sequence-out training, MOT20 transfer, all baselines, ablations, statistics, dynamic streams, YOLO11n study, timing |
| `experiments/download_mot20.py` | Downloads the four MOT20 training sequences (first 600 frames) |
| `results/` | Outputs used in the paper (CSV/JSON); see the table below |
| `figures_src/` | Scripts that regenerate the paper figures from `results/` |
| `figures/` | Paper figures (PDF) |

## Quick start (library)

```python
from sklearn.tree import DecisionTreeClassifier
from ppv_lite import PPVLite, FastTree

tree = FastTree(trained_clf)                 # DecisionTreeClassifier(max_depth=3, min_samples_leaf=20, class_weight="balanced")
sched = PPVLite(detector=my_detector, tree=tree, rho=0.25, tau=0.6, cap=1.5)
sched.reset(first_frame, t0=0)
for t, frame in enumerate(frames, start=1):
    boxes, conf, ran_detector = sched.step(frame, t)
```

`my_detector(image)` must return `(boxes[N,4] xyxy float32, conf[N] float32)`.

```bash
pip install -r requirements.txt
python -m pytest -q tests
```

## Reproducing the paper

1. Create a Kaggle notebook with a **GPU T4** accelerator and **Internet on**.
2. Add the MOT17 dataset as input (any copy containing `MOT17-0X-FRCNN/img1` and `gt/gt.txt` for sequences 02, 04, 05, 09, 10, 11, 13).
3. Paste `experiments/ppv_lite_pipeline.py` into one cell and run it. It downloads MOT20 and the YOLO11 weights automatically, caches detections in `/kaggle/working/ppv_v2`, and is checkpointed, so it can be re-run after an interruption. A full run takes about 3 to 4 hours.
4. Outputs: `/kaggle/working/ppv_v2/revision.zip` and `/kaggle/working/ppv_v2/revision2.zip`.

Set `RUN_TIMING, RUN_NANO, RUN_CPU = False, False, False` near the start of the revision block to skip the first timing set. `PPV_FAKE=1` runs a small synthetic self-test without a GPU (requires a fake MOT-format folder in `PPV_INPUT`).

### Fixed settings

| Item | Setting |
|---|---|
| Detector | Ultralytics `yolo11m.pt` (second detector `yolo11n.pt`), input 640, confidence 0.25, NMS IoU 0.7, person class |
| Features | 80x45 grayscale thumbnail; gap, entropy (32 bins), brightness change, previous mean confidence, scene difference |
| Classifier | DecisionTreeClassifier, depth 3, min. 20 samples per leaf, balanced class weights, random state 42 |
| Labels | gaps {1,...,6,8,10}, frames 1-600 of each training sequence |
| Controller | rho in {1/3, 1/4, 1/5, 1/6, 1/8, 1/10}; tau in {0.3,...,0.7}; C in {1.5, 2} ({1.5, 2, 3, 4} for dynamic-trained schedulers); c0 = 0 |
| Propagation | pyramidal Lucas-Kanade, window 21x21, 3 levels, 30 iterations, eps 0.01, quarter resolution |
| Evaluation | leave-one-sequence-out on frames 101-600 (MOT17-09: 101-525); MOT20 frames 101-600 (MOT20-01: 101-429) |
| Seeds | random placement 0-19; models 42; dynamic streams 1000 + 17 i + 101 j (sequence i, scenario j) |
| Paper environment | Tesla T4, driver 580.178.04, CUDA 12.8, Python 3.12.13, PyTorch 2.10.0, Ultralytics 8.4.172, OpenCV 4.13.0, scikit-learn 1.6.1 (`results/revision2/S0_environment.json`) |

## Results files and paper tables

| Paper item | File |
|---|---|
| Fig. 4, Tables 4-5 (LOSO accuracy) | `results/loso/mot17_loso_results.csv` |
| Table 10 (MOT20 transfer) | `results/loso/mot20_transfer_results.csv` |
| Tables 9, 11-14, 16-17, Fig. 8 (IoU/AP, ablations, call rates, timing set 1, labels, random spread) | `results/revision1/revision1_summary.txt` |
| Table 6 (equivalence margins) | `results/revision2/S1_margins.csv` |
| Table 7, Fig. 5a (gap-only and causal baselines) | `results/revision2/S2_normal.csv`, `S2_schedules.json`, `S2_S4_summary.csv` |
| Table 8, Figs. 5b and 6 (dynamic streams) | `results/revision2/S4_dynamic.csv`, `S4_head2head.csv`, `S4_schedules.json`, `S4_stream_frames.json` |
| Section 5.6 (YOLO11n) | `results/revision2/S5_nano.csv` |
| Table 15 (timing set 2) | `results/revision2/S6_timing_all.csv` |
| Table 3 (environment) | `results/revision2/S0_environment.json` |

Figures 1, 2, 3, 5, 6, 8 and 9 are regenerated with `cd figures_src && python make_method_figs.py && python make_rev_figs.py && python make_rev2_figs.py && python make_costmodel_fig.py`. Figure 4 is produced by the pipeline (`loso/fig_loso.pdf`). Figure 7 compares the earlier single-sequence threshold version with PPV-Lite and is included as a PDF.

## Data

MOT17 and MOT20 are available from the MOTChallenge benchmark (https://motchallenge.net) under their own licences; they are not redistributed here.

## Licence

MIT (see `LICENSE`).
