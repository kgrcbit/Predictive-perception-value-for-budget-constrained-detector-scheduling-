import re, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams.update({"font.family":"serif","font.serif":["Liberation Serif"],"mathtext.fontset":"stix","font.size":9})
txt=open("../results/revision1/revision1_summary.txt").read()
blk=txt.split("[R9/R10] online timing")[1].split("saving vs fixed")[0]
rows=[]; reg=meth=None
for line in blk.splitlines()[3:]:
    p=line.split()
    if not p: continue
    if p[0].startswith("yolo"): reg=p[0]; p=p[1:]
    if p[0] in ("fixed","framediff","periodic","ppv"): meth=p[0]; p=p[1:]
    v=[float(x) for x in p]; rows.append((reg,meth,v[0],v[3],v[4],v[10]))  # rho, ms, fps, f1
fig,axes=plt.subplots(1,2,figsize=(7.4,3.1))
sty={"ppv":("o-","#d62728","PPV-Lite"),"periodic":("s--","#1f77b4","Periodic"),"framediff":("^:","#2ca02c","Frame difference"),"fixed":("*","black","Fixed")}
for ax,reg,title in zip(axes,["yolo11m_gpu","yolo11n_gpu"],["YOLO11m, T4 GPU (7 sequences)","YOLO11n, T4 GPU (MOT17-02)"]):
    for m,(mk,c,lab) in sty.items():
        r=sorted([x for x in rows if x[0]==reg and x[1]==m],key=lambda x:x[3])
        ax.plot([x[3] for x in r],[x[5] for x in r],mk,color=c,label=lab,ms=10 if m=="fixed" else 5)
    ax.set_title(title,fontsize=9); ax.set_xlabel("End-to-end time per frame (ms)"); ax.grid(alpha=.3)
axes[0].set_ylabel("F1 (IoU 0.5), online"); axes[0].legend(fontsize=7.5,loc="lower right")
fig.tight_layout(); fig.savefig("../figures/fig_runtime_f1.pdf")
