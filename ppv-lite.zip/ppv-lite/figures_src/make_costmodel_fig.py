import sys, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt, numpy as np
plt.rcParams.update({"font.family": "serif", "font.serif": ["Liberation Serif"], "mathtext.fontset": "stix", "font.size": 9})
# measured points (phi/D, omega/D, label) can be passed later; default: none
pts = [(0.116, 0.164, 'YOLO11m GPU'), (0.171, 0.314, 'YOLO11n GPU'), (0.009, 0.014, 'YOLO11m CPU')]
fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.9), sharey=True)
r = np.linspace(0, 1, 200)
cols = ["#1f77b4", "#2ca02c", "#ff7f0e", "#d62728"]
for ax, c in zip(axes, [1/4, 1/10]):
    for w, col in zip([0.0, 0.1, 0.2, 0.4], cols):
        s = 100 * (1 - (c + (1 - c) * r + w))
        ax.plot(r, s, color=col, label=f"$\\omega/t_D={w:g}$")
    ax.axhline(100 * (1 - c), color="black", lw=0.8, ls="--")
    ax.text(0.98, 100 * (1 - c) + 2, f"call reduction {100*(1-c):.0f}%", ha="right", fontsize=8)
    for p in pts:
        ax.plot(p[0], 100 * (1 - (c + (1 - c) * p[0] + p[1])), "k*", ms=9)
        ax.annotate(p[2], (p[0], 100 * (1 - (c + (1 - c) * p[0] + p[1]))), xytext=(6, -2 if 'n G' in p[2] else 4), textcoords="offset points", fontsize=7.5)
    ax.set_title(f"one call in {round(1/c)} frames", fontsize=9)
    ax.set_xlabel("propagation cost per skipped frame, $\\phi/t_D$")
    ax.set_ylim(-30, 100); ax.set_xlim(0, 1); ax.grid(alpha=.3)
axes[0].set_ylabel("predicted runtime saving (%)")
axes[0].legend(fontsize=7.5, loc="lower left")
fig.tight_layout(); fig.savefig("../figures/fig_costmodel.pdf")
