"""Regenerate Figures 1-3 for the final five-feature, budget-controlled PPV-Lite."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Polygon

plt.rcParams.update({"font.family": "serif", "font.serif": ["Liberation Serif", "Times New Roman", "DejaVu Serif"],
                     "mathtext.fontset": "stix", "font.size": 9})
EDGE = "#1f3550"
FILL = {"in": "#eef3f8", "run": "#e6f2e6", "skip": "#f8e9ea", "off": "#f6f1dc", "frame": "#f7f8fa"}

def box(ax, x, y, w, h, text, kind="in", fs=8.5, bold_first=False):
    ax.add_patch(FancyBboxPatch((x - w / 2, y - h / 2), w, h, boxstyle="round,pad=0.012,rounding_size=0.025",
                                fc=FILL[kind], ec=EDGE, lw=1.3))
    ax.text(x, y, text, ha="center", va="center", fontsize=fs, color="#111")

def diamond(ax, x, y, w, h, text, fs=8.5):
    ax.add_patch(Polygon([(x, y + h / 2), (x + w / 2, y), (x, y - h / 2), (x - w / 2, y)], closed=True,
                         fc="white", ec=EDGE, lw=1.3))
    ax.text(x, y, text, ha="center", va="center", fontsize=fs)

def arrow(ax, p, q, text=None, tpos=None, dashed=False, fs=8):
    ax.annotate("", xy=q, xytext=p, arrowprops=dict(arrowstyle="-|>", color=EDGE, lw=1.3,
                                                     linestyle="--" if dashed else "-", shrinkA=0, shrinkB=0))
    if text:
        tx, ty = tpos if tpos else ((p[0] + q[0]) / 2, (p[1] + q[1]) / 2)
        ax.text(tx, ty, text, ha="center", va="center", fontsize=fs, fontweight="bold")

def canvas(w, h):
    fig, ax = plt.subplots(figsize=(w, h)); ax.set_xlim(0, w); ax.set_ylim(0, h); ax.axis("off")
    return fig, ax

# ---------------------------------------------------------------- Fig. 1 architecture
fig, ax = canvas(10.4, 3.1)
box(ax, 0.7, 2.05, 1.2, 0.62, "Input frame\n$I_t$")
box(ax, 2.4, 2.05, 1.7, 0.62, "Token bucket\n$c \\leftarrow c+\\rho$")
box(ax, 4.95, 2.05, 2.2, 0.78, "Five pre-inference features\n$X_t=[g_t,\\,H(I_t),\\,\\Delta\\mu_t,\\,\\bar c_k,\\,d_t]$\n(80$\\times$45 grayscale)", fs=8)
box(ax, 7.0, 2.05, 1.6, 0.78, "PPV-Lite tree\n(depth 3, 15 nodes)\n$\\hat p_t\\geq\\tau$ ?", fs=8)
box(ax, 9.05, 2.6, 2.0, 0.55, "RUN\nYOLO11m, $c\\leftarrow c-1$", "run", fs=8)
box(ax, 9.05, 1.45, 2.0, 0.55, "SKIP\nLucas–Kanade propagation", "skip", fs=8)
box(ax, 9.05, 0.45, 2.0, 0.55, "Perception state\nboxes, confidence, $k$", fs=8)
arrow(ax, (1.3, 2.05), (1.55, 2.05))
arrow(ax, (3.25, 2.05), (3.85, 2.05)); ax.text(3.55, 2.17, "$c\\geq1$", fontsize=8, ha="center")
arrow(ax, (6.05, 2.05), (6.2, 2.05))
arrow(ax, (7.8, 2.2), (8.05, 2.55), "yes", (7.82, 2.5))
arrow(ax, (7.8, 1.9), (8.05, 1.5), "no", (7.82, 1.6))
ax.annotate("", xy=(8.05, 2.75), xytext=(2.4, 2.36), arrowprops=dict(arrowstyle="-|>", color=EDGE, lw=1.2,
            connectionstyle="angle,angleA=90,angleB=180,rad=0"))
ax.text(5.2, 2.93, "forced RUN when $c\\geq C$ (no tree call)", fontsize=8, ha="center", fontweight="bold")
ax.text(2.4, 1.52, "if $c<1$: SKIP, no features", fontsize=7.5, ha="center")
ax.annotate("", xy=(10.12, 0.62), xytext=(10.07, 2.4), arrowprops=dict(arrowstyle="-|>", color=EDGE, lw=1.2,
            connectionstyle="arc3,rad=-0.3"))
arrow(ax, (9.05, 1.17), (9.05, 0.73))
ax.annotate("", xy=(4.95, 1.66), xytext=(8.05, 0.45), arrowprops=dict(arrowstyle="-|>", color=EDGE, lw=1.0,
            linestyle="--", connectionstyle="angle,angleA=180,angleB=-90,rad=0"))
ax.text(6.5, 0.28, "$k$, $I_k$ and $\\bar c_k$ feed the next frame's features", fontsize=7.5, ha="center")
box(ax, 1.95, 0.55, 3.2, 0.72, "Offline supervision only (training sequences):\n$\\Delta_t=F_1(B_t^D,G_t)-F_1(B_t^P,G_t)$,  $Y_t=\\mathbb{I}[\\Delta_t>0]$", "off", fs=7.8)
ax.annotate("", xy=(6.7, 1.64), xytext=(3.55, 0.8), arrowprops=dict(arrowstyle="-|>", color="#7a6a2a", lw=1.0,
            linestyle=":", connectionstyle="arc3,rad=-0.15"))
fig.savefig("../figures/fig1_architecture.pdf", bbox_inches="tight")

# ---------------------------------------------------------------- Fig. 2 protocol (one LOSO fold)
fig, ax = canvas(10.2, 3.6)
cols = [(1.75, "Training (six MOT17 sequences)"), (5.1, "Tuning (same six sequences)"), (8.45, "Test (held-out sequence)")]
for x, t in cols:
    ax.add_patch(FancyBboxPatch((x - 1.55, 0.12), 3.1, 3.3, boxstyle="round,pad=0.01,rounding_size=0.05",
                                fc=FILL["frame"], ec="#8792a2", lw=1.0))
    ax.text(x, 3.22, t, ha="center", fontsize=9.5, fontweight="bold")
steps = {
    1.75: [("YOLO11m detections and\nLK propagation, frames 1–600", "run"),
           ("Counterfactual pairs $(t,k)$, gaps\n$g\\in\\{1,\\ldots,6,8,10\\}$ (about 4,700 per sequence)", "in"),
           ("Label $Y_t=\\mathbb{I}[\\Delta_t>0]$ and\nfive features $X_t$", "in"),
           ("Fit depth-3 tree\n(min. 20 per leaf, balanced)", "in")],
    5.1: [("Run token-bucket scheduler on\nframes 101–600, six budgets $\\rho$", "in"),
          ("Grid $\\tau\\in\\{0.3,\\ldots,0.7\\}$, $C\\in\\{1.5,2\\}$", "in"),
          ("Pick $(\\tau,C)$ with the largest mean\nF1 gain over periodic placement", "off"),
          ("Freeze tree, $\\tau$ and $C$", "off")],
    8.45: [("Held-out sequence, frames 101–600\n(never used for training or tuning)", "run"),
           ("Online scheduler, six budgets;\nbaselines get the same call count", "in"),
           ("F1, AP, call counts, online timing", "in"),
           ("Repeat for all seven folds;\nMOT20: one tree on all MOT17", "in")],
}
for x, items in steps.items():
    ys = [2.72, 1.98, 1.24, 0.5]
    for (t, k), y in zip(items, ys):
        box(ax, x, y, 2.75, 0.56, t, k, fs=7.8)
    for a, b in zip(ys[:-1], ys[1:]):
        arrow(ax, (x, a - 0.29), (x, b + 0.29))
arrow(ax, (3.13, 0.5), (3.72, 2.72))
arrow(ax, (6.48, 0.5), (7.07, 2.42))
fig.savefig("../figures/fig2_methodology.pdf", bbox_inches="tight")

# ---------------------------------------------------------------- Fig. 3 online flow
fig, ax = canvas(11.2, 3.1)
def elbow(p, q, up=True, text=None, tpos=None):
    ax.annotate("", xy=q, xytext=p, arrowprops=dict(arrowstyle="-|>", color=EDGE, lw=1.3,
                connectionstyle="angle,angleA=%d,angleB=180,rad=0" % (90 if up else -90), shrinkA=0, shrinkB=0))
    if text: ax.text(*tpos, text, fontsize=8, fontweight="bold", ha="center")
Y = 1.55
box(ax, 0.6, Y, 1.0, 0.62, "Frame $I_t$")
box(ax, 1.95, Y, 1.25, 0.62, "$c\\leftarrow c+\\rho$")
diamond(ax, 3.4, Y, 1.15, 0.8, "$c\\geq1$ ?")
diamond(ax, 4.85, Y, 1.15, 0.8, "$c\\geq C$ ?")
box(ax, 6.45, Y, 1.55, 0.7, "Five features $X_t$,\ntree gives $\\hat p_t$", fs=8)
diamond(ax, 8.0, Y, 1.15, 0.8, "$\\hat p_t\\geq\\tau$ ?")
box(ax, 9.55, 2.62, 1.6, 0.62, "RUN: YOLO11m\n$k\\leftarrow t$, $c\\leftarrow c-1$", "run", fs=8)
box(ax, 9.55, 0.48, 1.6, 0.62, "SKIP: propagate\nboxes from $I_k$ to $I_t$", "skip", fs=8)
box(ax, 10.75, Y, 0.75, 0.62, "Next\nframe", fs=8)
arrow(ax, (1.1, Y), (1.32, Y)); arrow(ax, (2.58, Y), (2.82, Y))
arrow(ax, (3.98, Y), (4.27, Y), "yes", (4.12, Y + 0.17))
arrow(ax, (5.43, Y), (5.67, Y), "no", (5.55, Y + 0.17))
arrow(ax, (7.23, Y), (7.42, Y))
elbow((4.85, Y + 0.4), (8.75, 2.75), True, "yes", (5.05, 2.2))
elbow((8.0, Y + 0.4), (8.75, 2.48), True, "yes", (8.2, 2.2))
elbow((3.4, Y - 0.4), (8.75, 0.38), False, "no", (3.6, 0.85))
elbow((8.0, Y - 0.4), (8.75, 0.6), False, "no", (8.2, 0.85))
ax.text(5.6, 0.2, "no credit: skip without computing any feature", fontsize=7.5, ha="center")
arrow(ax, (10.35, 2.4), (10.6, 1.87)); arrow(ax, (10.35, 0.7), (10.6, 1.23))
fig.savefig("../figures/fig3_online.pdf", bbox_inches="tight")
print("ok")
