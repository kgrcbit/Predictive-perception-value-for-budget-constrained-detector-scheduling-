import json, numpy as np, pandas as pd, itertools, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams.update({"font.family":"serif","font.serif":["Liberation Serif"],"mathtext.fontset":"stix","font.size":9})
R="../results/revision2/"
COL={"periodic":"#1f77b4","gap_only":"#9467bd","ppv":"#d62728","fd_bisect":"#2ca02c","ppv_dyn":"#ff7f0e","gap_dyn":"#8c564b","unc_bisect":"#17becf"}
LAB={"periodic":"Periodic","gap_only":"Gap-only tree","ppv":"PPV-Lite","fd_bisect":"Frame difference","ppv_dyn":"PPV-Lite (dynamic-trained)","gap_dyn":"Gap-only (dynamic-trained)","unc_bisect":"Tracking uncertainty"}
# ---- Fig A: placement on normal video
sch=json.load(open(R+"S2_schedules.json")); sf=json.load(open(R+"S4_stream_frames.json")); s4=json.load(open(R+"S4_schedules.json"))
fig,ax=plt.subplots(1,2,figsize=(7.4,2.9),gridspec_kw={"width_ratios":[1,1.35]})
bins=np.arange(0.5,16.5,1)
for i,m in enumerate(["periodic","gap_only","ppv","fd_bisect"]):
    g=[]
    for k,v in sch.items():
        s,r,mm=k.split("|")
        if mm==m and r=="0.25": g+=list(np.diff([100]+v))
    h,_=np.histogram(np.clip(g,1,15),bins=bins)
    ax[0].plot(np.arange(1,16),h/h.sum(),"o-",ms=3,color=COL[m],label=LAB[m])
ax[0].set_xlabel("frames between detector calls ($\\rho=1/4$)"); ax[0].set_ylabel("share of calls"); ax[0].set_title("(a) Gap distribution, MOT17",fontsize=9)
ax[0].legend(fontsize=7); ax[0].grid(alpha=.3); ax[0].text(15,0.02,"$\\geq$15",fontsize=7,ha="center")
# ---- raster on a jump stream
seq="MOT17-13-FRCNN"; rho="0.125"
src=sf[f"jump|{seq}"]; jumps=[i+1 for i in range(1,len(src)) if src[i]-src[i-1]!=1]
lo,hi=101,300
for j in jumps:
    if lo<=j<=hi: ax[1].axvline(j,color="0.6",lw=0.8,ls="--")
for y,m in enumerate(["periodic","gap_only","ppv","ppv_dyn","unc_bisect"]):
    v=[x for x in s4[f"jump|{seq}|{rho}|{m}"] if lo<=x<=hi]
    ax[1].plot(v,[y]*len(v),"|",ms=12,mew=1.6,color=COL[m])
ax[1].set_yticks(range(5)); ax[1].set_yticklabels([LAB[m] for m in ["periodic","gap_only","ppv","ppv_dyn","unc_bisect"]],fontsize=7.5)
ax[1].set_xlim(lo,hi); ax[1].set_ylim(-0.6,4.6); ax[1].set_xlabel("frame of the jump stream (dashed: abrupt jump)")
ax[1].set_title("(b) Detector calls, jump stream from MOT17-13, $\\rho=1/8$",fontsize=9)
fig.tight_layout(); fig.savefig("../figures/fig_placement.pdf")
# ---- Fig B: dynamic results bars
d=pd.read_csv(R+"S4_dynamic.csv"); n=pd.read_csv(R+"S2_normal.csv")
meths=["gap_only","ppv","gap_dyn","ppv_dyn","unc_bisect"]
sc=[("normal",n),("jump",d[d.scenario=="jump"]),("burst",d[d.scenario=="burst"]),("mixed",d[d.scenario=="mixed"])]
fig,ax=plt.subplots(figsize=(7.2,3.2)); w=0.16
for i,m in enumerate(meths):
    mu=[];se=[]
    for name,df in sc:
        x=df[df.method==m].groupby("seq").d_periodic.mean()
        mu.append(x.mean() if len(x) else np.nan); se.append(x.std(ddof=1)/np.sqrt(len(x)) if len(x)>1 else np.nan)
    xs=np.arange(4)+(i-2)*w
    ax.bar(xs,mu,w,yerr=se,color=COL[m],label=LAB[m],capsize=2,error_kw={"lw":0.8})
ax.axhline(0,color="black",lw=0.8); ax.set_xticks(range(4)); ax.set_xticklabels(["Normal MOT17","Abrupt jumps","Speed bursts","Mixed"])
ax.set_ylabel("F1 minus periodic (same calls)"); ax.legend(fontsize=7,ncol=3,loc="lower center",bbox_to_anchor=(0.5,1.0),frameon=False); ax.grid(axis="y",alpha=.3)
fig.tight_layout(); fig.savefig("../figures/fig_dynamic.pdf")
