# =====================================================================
# ppv_lite_pipeline.py  -  complete PPV-Lite experiment pipeline (Kaggle, GPU T4, Internet ON)
# Paste the whole file into one cell and run. About 2 hours on a
# fresh session (detector caches are rebuilt first), less if
# /kaggle/working/ppv_v2 is still there. Checkpointed: if it stops, run again.
# When it finishes: download /kaggle/working/ppv_v2/revision2.zip and upload it
# to the chat (or paste everything after "=== REVISION 2 SUMMARY ===").
# =====================================================================
import os
if os.environ.get("PPV_FAKE") != "1":
    # =====================================================================
    # DOWNLOAD MOT20 (official MOTChallenge site). Needs Internet ON.
    # Downloads about 5 GB, then extracts only the 4 TRAIN sequences,
    # first 600 frames each, plus their ground truth (about 1 GB on disk).
    # Takes roughly 5 to 15 minutes. Run once; it skips work already done.
    # =====================================================================
    import os, zipfile, urllib.request, shutil, time

    URL = "https://motchallenge.net/data/MOT20.zip"
    ZIP = "/kaggle/tmp_mot20.zip"
    DEST = "/kaggle/ext_data"
    KEEP_FRAMES = 600
    os.makedirs(DEST, exist_ok=True)

    done = [d for d in os.listdir(DEST) if d.startswith("MOT20-")] if os.path.isdir(DEST) else []
    if len(done) >= 4:
        print("MOT20 already extracted:", sorted(done))
    else:
        if not os.path.exists(ZIP):
            t0 = time.time(); print("Downloading", URL)
            def hook(b, bs, total):
                if b % 2000 == 0 and total > 0:
                    print(f"  {min(100, b * bs * 100 / total):5.1f}%  {time.time()-t0:.0f}s")
            urllib.request.urlretrieve(URL, ZIP, hook)
        print("Extracting train sequences ...")
        with zipfile.ZipFile(ZIP) as z:
            for name in z.namelist():
                parts = name.split("/")
                if "train" not in parts or name.endswith("/"):
                    continue
                seq = parts[parts.index("train") + 1]
                rest = parts[parts.index("train") + 2:]
                if rest[:1] == ["img1"]:
                    if int(os.path.splitext(rest[1])[0]) > KEEP_FRAMES:
                        continue
                elif rest != ["gt", "gt.txt"]:
                    continue
                out = os.path.join(DEST, seq, *rest)
                os.makedirs(os.path.dirname(out), exist_ok=True)
                with z.open(name) as src, open(out, "wb") as dst:
                    shutil.copyfileobj(src, dst)
        os.remove(ZIP)                      # free the 5 GB
        print("Done:", sorted(d for d in os.listdir(DEST) if d.startswith("MOT20-")))
    for d in sorted(os.listdir(DEST)):
        p = os.path.join(DEST, d, "img1")
        if os.path.isdir(p):
            print(f"  {d}: {len(os.listdir(p))} frames")

# %% CELL 1 =============================================================
import os, sys, glob, time, json, pickle, subprocess, warnings
import numpy as np
import pandas as pd
import cv2
warnings.filterwarnings("ignore")

FAKE = os.environ.get("PPV_FAKE") == "1"          # local self-test only
INPUT_ROOT = os.environ.get("PPV_INPUT", "/kaggle/input")
OUT = os.environ.get("PPV_OUT", "/kaggle/working/ppv_v2")
os.makedirs(OUT, exist_ok=True)

SEQS = ["MOT17-02-FRCNN", "MOT17-04-FRCNN", "MOT17-05-FRCNN",
        "MOT17-09-FRCNN", "MOT17-10-FRCNN", "MOT17-11-FRCNN",
        "MOT17-13-FRCNN"]
MAX_FRAMES = 600            # frames 1..600 (or fewer if sequence is shorter)
FLOW_SCALE = 0.25
SMALL = (80, 45)            # feature resolution used in the paper

# ---------- discover sequences (needs img1 + gt/gt.txt) ----------
found = {}
for img_dir in glob.glob(os.path.join(INPUT_ROOT, "**", "img1"), recursive=True):
    seq = os.path.basename(os.path.dirname(img_dir))
    gt = os.path.join(os.path.dirname(img_dir), "gt", "gt.txt")
    if seq in SEQS and os.path.exists(gt) and seq not in found:
        found[seq] = img_dir
print("Sequences found:")
for s in SEQS:
    print(f"  {'OK ' if s in found else 'MISSING'} {s}  {found.get(s, '')}")
if "MOT17-02-FRCNN" not in found:
    raise RuntimeError("MOT17-02-FRCNN with gt is required (training sequence).")
SEQS = [s for s in SEQS if s in found]

# ---------- detector ----------
if FAKE:
    class _Box:
        def __init__(self, b, c):
            self.xyxy = _T(b); self.conf = _T(c); self.cls = _T(np.zeros(len(c)))
        def __len__(self): return len(self.conf.a)
    class _T:
        def __init__(self, a): self.a = np.asarray(a, dtype=np.float32)
        def detach(self): return self
        def cpu(self): return self
        def numpy(self): return self.a
    class _R:
        def __init__(self, b, c): self.boxes = _Box(b, c)
    class FakeYOLO:
        def __call__(self, imgs, verbose=False, device=None):
            out = []
            for im in imgs:
                b = FAKE_GT_LOOKUP[id(im)]
                rng = np.random.default_rng(len(b))
                jit = b + rng.normal(0, 4, b.shape) if len(b) else b
                out.append(_R(jit, np.full(len(b), 0.8)))
            return out
    model = FakeYOLO()
    FAKE_GT_LOOKUP = {}
else:
    try:
        from ultralytics import YOLO
    except ImportError:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "ultralytics"])
        from ultralytics import YOLO
    import torch
    model = YOLO("yolo11m.pt")          # explicit: never falls back to another model
    print("Detector: yolo11m.pt | CUDA:", torch.cuda.is_available())
    _d = np.zeros((1080, 1920, 3), np.uint8)
    for _ in range(10):
        model([_d], verbose=False, device=0)

def load_gt(seq):
    gt_path = os.path.join(os.path.dirname(found[seq]), "gt", "gt.txt")
    df = pd.read_csv(gt_path, header=None)
    out = {}
    for r in df.itertuples(index=False):
        f, x, y, w, h, flag, cls = int(r[0]), r[2], r[3], r[4], r[5], r[6], int(r[7])
        if cls != 1 or flag <= 0 or w <= 0 or h <= 0:
            continue
        out.setdefault(f, []).append([x, y, x + w, y + h])
    return {k: np.asarray(v, np.float32) for k, v in out.items()}

def build_sequence(seq):
    """YOLO11m person detections + small grayscale frames, checkpointed."""
    path = os.path.join(OUT, f"{seq}_cache.pkl")
    if os.path.exists(path):
        with open(path, "rb") as f:
            c = pickle.load(f)
        if c.get("complete"):
            return c
    files = sorted(glob.glob(os.path.join(found[seq], "*.jpg")))[:MAX_FRAMES]
    gt = load_gt(seq)
    c = {"seq": seq, "n": len(files), "det": {}, "small": {}, "flow": {},
         "gt": gt, "complete": False}
    batch, ids = [], []
    t_det = 0.0
    for i, fp in enumerate(files, start=1):
        img = cv2.imread(fp)
        if img is None:
            raise FileNotFoundError(fp)
        if i == 1:
            c["H"], c["W"] = img.shape[:2]
        g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        c["small"][i] = cv2.resize(g, SMALL, interpolation=cv2.INTER_AREA)
        c["flow"][i] = cv2.resize(g, None, fx=FLOW_SCALE, fy=FLOW_SCALE,
                                  interpolation=cv2.INTER_AREA)
        if FAKE:
            FAKE_GT_LOOKUP[id(img)] = gt.get(i, np.zeros((0, 4), np.float32))
        batch.append(img); ids.append(i)
        if len(batch) == 16 or i == len(files):
            t0 = time.perf_counter()
            res = model(batch, verbose=False, device=0)
            t_det += time.perf_counter() - t0
            for fid, r in zip(ids, res):
                if r.boxes is None or len(r.boxes) == 0:
                    b = np.zeros((0, 4), np.float32); cf = np.zeros(0, np.float32)
                else:
                    b = r.boxes.xyxy.detach().cpu().numpy().astype(np.float32)
                    cf = r.boxes.conf.detach().cpu().numpy().astype(np.float32)
                    k = r.boxes.cls.detach().cpu().numpy().astype(np.int32) == 0
                    b, cf = b[k], cf[k]          # COCO person only
                c["det"][fid] = {"boxes": b, "conf": cf}
            batch, ids = [], []
    c["complete"] = True
    with open(path, "wb") as f:
        pickle.dump(c, f, protocol=pickle.HIGHEST_PROTOCOL)
    print(f"  cached {seq}: {c['n']} frames, {c['W']}x{c['H']}, batch detector {t_det:.1f}s")
    return c

DATA = {}
for s in SEQS:
    DATA[s] = build_sequence(s)
print("CELL 1 done:", {s: DATA[s]["n"] for s in SEQS})



# %% CELL 2 =============================================================
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import roc_auc_score, accuracy_score

def iou_matrix(a, b):
    if len(a) == 0 or len(b) == 0:
        return np.zeros((len(a), len(b)), np.float32)
    x1 = np.maximum(a[:, None, 0], b[None, :, 0]); y1 = np.maximum(a[:, None, 1], b[None, :, 1])
    x2 = np.minimum(a[:, None, 2], b[None, :, 2]); y2 = np.minimum(a[:, None, 3], b[None, :, 3])
    inter = np.clip(x2 - x1, 0, None) * np.clip(y2 - y1, 0, None)
    aa = (a[:, 2] - a[:, 0]) * (a[:, 3] - a[:, 1]); bb = (b[:, 2] - b[:, 0]) * (b[:, 3] - b[:, 1])
    union = aa[:, None] + bb[None, :] - inter
    return np.where(union > 0, inter / np.maximum(union, 1e-9), 0)

def match_counts(det, gt, thr=0.5):
    det = np.asarray(det, np.float32).reshape(-1, 4)
    gt = np.asarray(gt, np.float32).reshape(-1, 4)
    if len(det) == 0 or len(gt) == 0:
        return 0, len(det), len(gt)
    m = iou_matrix(det, gt)
    di, gi = np.nonzero(m >= thr)
    order = np.argsort(-m[di, gi])
    ud, ug, tp = set(), set(), 0
    for o in order:
        d, g = di[o], gi[o]
        if d in ud or g in ug:
            continue
        ud.add(d); ug.add(g); tp += 1
    return tp, len(det) - tp, len(gt) - tp

def prf(tp, fp, fn):
    p = tp / (tp + fp) if tp + fp else 0.0
    r = tp / (tp + fn) if tp + fn else 0.0
    return p, r, (2 * p * r / (p + r) if p + r else 0.0)

class Seq:
    """Memoised detector / propagation outcomes for one sequence."""
    def __init__(self, c):
        self.c = c; self.gt = c["gt"]; self.W = c["W"]; self.H = c["H"]
        self._det_cnt = {}; self._prop = {}; self._prop_cnt = {}
    def gt_of(self, f):
        return self.gt.get(f, np.zeros((0, 4), np.float32))
    def det_counts(self, f):
        if f not in self._det_cnt:
            self._det_cnt[f] = match_counts(self.c["det"][f]["boxes"], self.gt_of(f))
        return self._det_cnt[f]
    def propagate(self, k, t):
        key = (k, t)
        if key in self._prop:
            return self._prop[key]
        boxes = self.c["det"][k]["boxes"]
        if len(boxes) == 0:
            self._prop[key] = boxes; return boxes
        s = FLOW_SCALE
        x1, y1, x2, y2 = boxes[:, 0], boxes[:, 1], boxes[:, 2], boxes[:, 3]
        pts = np.stack([np.stack([x1, y1], 1), np.stack([x2, y1], 1), np.stack([x1, y2], 1),
                        np.stack([x2, y2], 1), np.stack([(x1 + x2) / 2, (y1 + y2) / 2], 1)], 1)
        p0 = (pts.reshape(-1, 2) * s).astype(np.float32).reshape(-1, 1, 2)
        p1, st, _ = cv2.calcOpticalFlowPyrLK(
            self.c["flow"][k], self.c["flow"][t], p0, None, winSize=(21, 21), maxLevel=3,
            criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, 0.01))
        if p1 is None or st is None:
            self._prop[key] = boxes.copy(); return boxes
        disp = ((p1 - p0).reshape(-1, 5, 2)) / s
        ok = st.reshape(-1, 5) > 0
        out = []
        for i, b in enumerate(boxes):
            if ok[i].sum() < 3:
                out.append(b.copy()); continue
            dx = float(np.median(disp[i, ok[i], 0])); dy = float(np.median(disp[i, ok[i], 1]))
            nb = [np.clip(b[0] + dx, 0, self.W - 1), np.clip(b[1] + dy, 0, self.H - 1),
                  np.clip(b[2] + dx, 0, self.W - 1), np.clip(b[3] + dy, 0, self.H - 1)]
            if nb[2] > nb[0] and nb[3] > nb[1]:
                out.append(nb)
        res = np.asarray(out, np.float32).reshape(-1, 4)
        self._prop[key] = res
        return res
    def prop_counts(self, k, t):
        key = (k, t)
        if key not in self._prop_cnt:
            self._prop_cnt[key] = match_counts(self.propagate(k, t), self.gt_of(t))
        return self._prop_cnt[key]
    # ----- the four PPV-Lite features (as in the notebook) -----
    def entropy(self, f):
        h = cv2.calcHist([self.c["small"][f]], [0], None, [32], [0, 256]).ravel()
        p = h / h.sum() if h.sum() > 0 else h
        p = p[p > 0]
        return float(-(p * np.log2(p)).sum()) if len(p) else 0.0
    def features(self, t, k):
        bc = float(self.c["small"][t].mean() / 255.0 - self.c["small"][k].mean() / 255.0)
        conf = self.c["det"][k]["conf"]
        return [t - k, self.entropy(t), bc, float(conf.mean()) if len(conf) else 0.0]
    def scene_diff(self, t, k):
        a = self.c["small"][t].astype(np.float32); b = self.c["small"][k].astype(np.float32)
        return float(np.abs(a - b).mean() / 255.0)

S = {s: Seq(DATA[s]) for s in SEQS}
FEATS = ["gap", "entropy", "brightness_change", "mean_confidence_previous"]
TREE_FILE = os.path.join(OUT, "ppv_lite_tree_v2.pkl")

def build_labels(seq, f_lo, f_hi, gaps=(1, 2, 3, 5, 6)):
    sq, rows = S[seq], []
    for t in range(max(2, f_lo), f_hi + 1):
        for g in gaps:
            k = t - g
            if k < 1:
                continue
            _, _, f_run = prf(*sq.det_counts(t))
            _, _, f_flow = prf(*sq.prop_counts(k, t))
            rows.append([t, *sq.features(t, k), int(f_run > f_flow)])
    return pd.DataFrame(rows, columns=["frame"] + FEATS + ["beneficial"])

if os.path.exists(TREE_FILE):
    with open(TREE_FILE, "rb") as f:
        TREE = pickle.load(f)
    print("Loaded tree:", TREE_FILE)
else:
    lab = build_labels("MOT17-02-FRCNN", 1, 600)
    lab.to_csv(os.path.join(OUT, "mot17_02_ppv_labels_v2.csv"), index=False)
    tr = lab[lab.frame <= 400]; va = lab[(lab.frame >= 401) & (lab.frame <= 500)]
    te = lab[lab.frame >= 501]
    TREE = DecisionTreeClassifier(max_depth=3, min_samples_leaf=8,
                                  class_weight="balanced", random_state=42)
    TREE.fit(tr[FEATS].values, tr["beneficial"].values)
    for name, d in [("val", va), ("test", te)]:
        pr = TREE.predict_proba(d[FEATS].values)[:, 1]
        auc = roc_auc_score(d["beneficial"], pr) if d["beneficial"].nunique() > 1 else float("nan")
        print(f"  tree {name}: acc={accuracy_score(d['beneficial'], pr >= 0.5):.4f} auc={auc:.4f} "
              f"pos_rate={d['beneficial'].mean():.3f} n={len(d)}")
    with open(TREE_FILE, "wb") as f:
        pickle.dump(TREE, f)
print("Tree depth", TREE.get_depth(), "nodes", TREE.tree_.node_count,
      "importances", dict(zip(FEATS, np.round(TREE.feature_importances_, 4))))
print("CELL 2 done")



# %% CELL 3 =============================================================
TAU = 0.65
GMAX_LIST = [3, 4, 5, 6, 8, 10]     # each gives a different detector budget
N_RANDOM = 20

def window(seq):
    """Held-out frames. MOT17-02 trained on 1-500, so test on 501-600 only.
    Other sequences were never seen in training: use frames 101..end."""
    n = DATA[seq]["n"]
    return (501, min(600, n)) if seq == "MOT17-02-FRCNN" else (101, min(600, n))

def eval_schedule(seq, run_frames, lo, hi):
    """Pooled P/R/F1 when the detector runs on run_frames and flow fills the rest."""
    sq, run = S[seq], set(run_frames)
    tp = fp = fn = 0; k = lo - 1        # detector state at lo-1 is available
    for t in range(lo, hi + 1):
        if t in run:
            a, b, c = sq.det_counts(t); k = t
        else:
            a, b, c = sq.prop_counts(k, t)
        tp += a; fp += b; fn += c
    return prf(tp, fp, fn)

def ppv_schedule(seq, lo, hi, gmax, tau=TAU):
    sq, k, runs = S[seq], lo - 1, []
    for t in range(lo, hi + 1):
        p = TREE.predict_proba(np.asarray([sq.features(t, k)], np.float32))[0, 1]
        if p >= tau or (t - k) >= gmax:
            runs.append(t); k = t
    return runs

def timer_schedule(lo, hi, g):           # "detect every g frames" (gap-only rule)
    return list(range(lo + g - 1, hi + 1, g))

def periodic_schedule(lo, hi, n):        # n calls spread evenly
    if n <= 0:
        return []
    L = hi - lo + 1
    return sorted(set(int(round(lo + (i + 1) * L / n - 1)) for i in range(n)))

def random_schedule(lo, hi, n, seed):
    rng = np.random.default_rng(seed)
    return sorted(rng.choice(np.arange(lo, hi + 1), size=n, replace=False).tolist())

def framediff_schedule(seq, lo, hi, n):
    """Causal baseline: run when mean |frame - last detector frame| exceeds a
    threshold; threshold set by bisection so the call count equals n."""
    sq = S[seq]
    def run(th):
        k, r = lo - 1, []
        for t in range(lo, hi + 1):
            if sq.scene_diff(t, k) >= th:
                r.append(t); k = t
        return r
    a, b = 0.0, 1.0
    best = run(0.0)
    for _ in range(40):
        m = (a + b) / 2; r = run(m)
        if len(r) > n: a = m
        else: b = m; best = r
        if len(r) == n:
            return r
    return best

RES_FILE = os.path.join(OUT, "budget_sweep_v2.csv")
done = pd.read_csv(RES_FILE) if os.path.exists(RES_FILE) else pd.DataFrame()
rows = done.to_dict("records")
done_keys = {(r["seq"], int(r["gmax"])) for r in rows}
t_start = time.time()
for seq in SEQS:
    lo, hi = window(seq)
    if hi - lo < 20:
        print("skip", seq, "(window too short)"); continue
    fixed = eval_schedule(seq, range(lo, hi + 1), lo, hi)
    for g in GMAX_LIST:
        if (seq, g) in done_keys:
            continue
        ppv = ppv_schedule(seq, lo, hi, g)
        n = len(ppv)
        res = {"seq": seq, "lo": lo, "hi": hi, "frames": hi - lo + 1, "gmax": g, "calls": n,
               "fixed_f1": fixed[2],
               "ppv_p": None, "ppv_r": None, "ppv_f1": None}
        res["ppv_p"], res["ppv_r"], res["ppv_f1"] = eval_schedule(seq, ppv, lo, hi)
        res["periodic_f1"] = eval_schedule(seq, periodic_schedule(lo, hi, n), lo, hi)[2]
        tm = timer_schedule(lo, hi, g)
        res["timer_calls"] = len(tm)
        res["timer_f1"] = eval_schedule(seq, tm, lo, hi)[2]
        fd = framediff_schedule(seq, lo, hi, n)
        res["framediff_calls"] = len(fd)
        res["framediff_f1"] = eval_schedule(seq, fd, lo, hi)[2]
        rf = [eval_schedule(seq, random_schedule(lo, hi, n, sd), lo, hi)[2] for sd in range(N_RANDOM)]
        res["random_mean"] = float(np.mean(rf)); res["random_std"] = float(np.std(rf))
        res["random_max"] = float(np.max(rf))
        res["ppv_beats_random"] = int(sum(res["ppv_f1"] > x for x in rf))
        rows.append(res)
        pd.DataFrame(rows).to_csv(RES_FILE, index=False)      # checkpoint
        print(f"{seq} G={g:>2} calls={n:>3}/{hi-lo+1} | PPV {res['ppv_f1']:.4f} "
              f"periodic {res['periodic_f1']:.4f} timer {res['timer_f1']:.4f}({len(tm)}) "
              f"fdiff {res['framediff_f1']:.4f} rand {res['random_mean']:.4f}+-{res['random_std']:.4f} "
              f"fixed {fixed[2]:.4f} | {time.time()-t_start:.0f}s")

sweep = pd.DataFrame(rows)
sweep["ppv_minus_periodic"] = sweep["ppv_f1"] - sweep["periodic_f1"]
sweep["ppv_minus_framediff"] = sweep["ppv_f1"] - sweep["framediff_f1"]
sweep["ppv_retention_pct"] = 100 * sweep["ppv_f1"] / sweep["fixed_f1"]
sweep.to_csv(RES_FILE, index=False)

# ---------- statistics: paired over (sequence, budget) ----------
from scipy.stats import wilcoxon
UNIQ = sweep.drop_duplicates(subset=["seq", "calls"])   # same schedule counted once
def paired(col):
    d = UNIQ[col].values
    d = d[np.abs(d) > 1e-12]
    if len(d) < 6:
        return {"n": len(d), "wins": int((d > 0).sum()), "p": float("nan")}
    return {"n": len(d), "wins": int((d > 0).sum()), "mean": float(d.mean()),
            "p": float(wilcoxon(d, alternative="greater").pvalue)}
STATS = {"ppv_vs_periodic": paired("ppv_minus_periodic"),
         "ppv_vs_framediff": paired("ppv_minus_framediff")}
sweep["ppv_minus_random"] = sweep["ppv_f1"] - sweep["random_mean"]
UNIQ = sweep.drop_duplicates(subset=["seq", "calls"])
STATS["ppv_vs_random_mean"] = paired("ppv_minus_random")
STATS["unique_schedules"] = int(len(UNIQ))
print("\nPaired one-sided Wilcoxon over (sequence, budget) pairs:")
for k, v in STATS.items():
    print(" ", k, v)
json.dump(STATS, open(os.path.join(OUT, "stats_v2.json"), "w"), indent=1)

# ---------- colour figure: F1 vs detector calls, one panel per sequence ----------
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
seqs_done = list(dict.fromkeys(sweep["seq"]))
cols = 4; rws = int(np.ceil(len(seqs_done) / cols))
fig, axes = plt.subplots(rws, cols, figsize=(4.2 * cols, 3.2 * rws), squeeze=False)
for ax, seq in zip(axes.ravel(), seqs_done):
    d = sweep[sweep.seq == seq].sort_values("calls")
    pct = 100 * d["calls"] / d["frames"]
    ax.plot(pct, d["ppv_f1"], "o-", color="#d62728", label="PPV-Lite")
    ax.plot(pct, d["periodic_f1"], "s--", color="#1f77b4", label="Periodic")
    ax.plot(pct, d["framediff_f1"], "^:", color="#2ca02c", label="Frame-diff")
    ax.errorbar(pct, d["random_mean"], yerr=d["random_std"], fmt="d-", color="#7f7f7f",
                alpha=.8, label="Random (mean, sd)")
    ax.axhline(d["fixed_f1"].iloc[0], color="black", lw=1, label="Fixed (every frame)")
    ax.set_title(seq.replace("-FRCNN", ""), fontsize=10)
    ax.set_xlabel("Detector calls (% of frames)"); ax.set_ylabel("F1 (IoU 0.5)")
for ax in axes.ravel()[len(seqs_done):]:
    ax.axis("off")
axes.ravel()[0].legend(fontsize=7, loc="lower right")
fig.tight_layout()
fig.savefig(os.path.join(OUT, "fig_budget_sweep_v2.pdf")); fig.savefig(os.path.join(OUT, "fig_budget_sweep_v2.png"), dpi=200)
print("CELL 3 done. Figure:", os.path.join(OUT, "fig_budget_sweep_v2.pdf"))



# %% CELL 6 =============================================================
# OPTION 1: fixed method. Run cells 1, 2 and 3 first in the same session
# (they reload from checkpoints). Then cells 6, 7 and 8.
#
# Changes versus PPV-Lite v1:
#   (a) leave-one-sequence-out: train on 6 sequences, test on the 7th
#   (b) fifth feature: scene difference to the last detector frame
#   (c) budget control: a token bucket fills at rate rho per frame; the tree
#       may spend a token when its predicted benefit >= tau, and must spend
#       one when the bucket reaches `cap`. Calls therefore track rho * frames,
#       and the tree only decides WHEN, inside a bounded window.
#   (d) tau and cap are tuned on the 6 training sequences only.
FEATS5 = FEATS + ["scene_diff"]
LABEL_GAPS = (1, 2, 3, 4, 5, 6, 8, 10)
RHOS = [1/3, 1/4, 1/5, 1/6, 1/8, 1/10]          # target call rates
TAU_GRID = [0.3, 0.4, 0.5, 0.6, 0.7]
CAP_GRID = [1.5, 2.0]
LOSO_DIR = os.path.join(OUT, "loso")
os.makedirs(LOSO_DIR, exist_ok=True)

def feats5(sq, t, k):
    return sq.features(t, k) + [sq.scene_diff(t, k)]

def labels5(seq):
    path = os.path.join(LOSO_DIR, f"labels_{seq}.csv")
    if os.path.exists(path):
        return pd.read_csv(path)
    sq, rows, n = S[seq], [], DATA[seq]["n"]
    for t in range(2, n + 1):
        _, _, f_run = prf(*sq.det_counts(t))
        for g in LABEL_GAPS:
            k = t - g
            if k < 1:
                continue
            _, _, f_flow = prf(*sq.prop_counts(k, t))
            rows.append([seq, t, *feats5(sq, t, k), int(f_run > f_flow), f_run - f_flow])
    df = pd.DataFrame(rows, columns=["seq", "frame"] + FEATS5 + ["beneficial", "delta"])
    df.to_csv(path, index=False)
    return df

t0 = time.time()
LAB = {}
for s in SEQS:
    LAB[s] = labels5(s)
    print(f"  labels {s}: {len(LAB[s])} rows, positive rate {LAB[s]['beneficial'].mean():.3f} "
          f"| {time.time()-t0:.0f}s")

class FastTree:
    """Hand-rolled predict for a fitted sklearn tree (about 50x faster per row)."""
    def __init__(self, clf):
        t = clf.tree_
        self.l, self.r, self.f, self.th = t.children_left, t.children_right, t.feature, t.threshold
        v = t.value[:, 0, :]
        self.p = v[:, 1] / np.maximum(v.sum(1), 1e-12)
    def __call__(self, x):
        n = 0
        while self.l[n] != -1:
            n = self.l[n] if x[self.f[n]] <= self.th[n] else self.r[n]
        return self.p[n]

def ppv_budget_schedule(seq, lo, hi, rho, tau, cap, tree):
    sq, k, c, runs = S[seq], lo - 1, 0.0, []
    for t in range(lo, hi + 1):
        c += rho
        if c >= 1.0 and (c >= cap or tree(feats5(sq, t, k)) >= tau):
            runs.append(t); k = t; c -= 1.0
    return runs

def win2(seq):
    n = DATA[seq]["n"]
    return 101, min(600, n)          # same window for every sequence in LOSO

def fold(test_seq):
    path = os.path.join(LOSO_DIR, f"fold_{test_seq}.pkl")
    if os.path.exists(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    train = [s for s in SEQS if s != test_seq]
    df = pd.concat([LAB[s] for s in train])
    clf = DecisionTreeClassifier(max_depth=3, min_samples_leaf=20,
                                 class_weight="balanced", random_state=42)
    clf.fit(df[FEATS5].values, df["beneficial"].values)
    ft = FastTree(clf)
    # tune tau and cap on the TRAINING sequences only
    best, grid = None, []
    for tau in TAU_GRID:
        for cap in CAP_GRID:
            gains = []
            for s in train:
                lo, hi = win2(s)
                for rho in RHOS:
                    runs = ppv_budget_schedule(s, lo, hi, rho, tau, cap, ft)
                    f_ppv = eval_schedule(s, runs, lo, hi)[2]
                    f_per = eval_schedule(s, periodic_schedule(lo, hi, len(runs)), lo, hi)[2]
                    gains.append(f_ppv - f_per)
            g = float(np.mean(gains)); grid.append((tau, cap, g))
            if best is None or g > best[2]:
                best = (tau, cap, g)
    res = {"test": test_seq, "clf": clf, "tau": best[0], "cap": best[1],
           "train_gain": best[2], "grid": grid,
           "importance": dict(zip(FEATS5, clf.feature_importances_.round(4)))}
    with open(path, "wb") as f:
        pickle.dump(res, f)
    return res

FOLDS = {}
for s in SEQS:
    FOLDS[s] = fold(s)
    fd = FOLDS[s]
    print(f"  fold test={s}: tau={fd['tau']} cap={fd['cap']} train gain vs periodic "
          f"{fd['train_gain']:+.4f} | importance {fd['importance']} | {time.time()-t0:.0f}s")
print("CELL 6 done")



# %% CELL 7 =============================================================
LOSO_FILE = os.path.join(LOSO_DIR, "loso_results.csv")
lrows = []
for s in SEQS:
    fd = FOLDS[s]; ft = FastTree(fd["clf"])
    lo, hi = win2(s)
    fixed = eval_schedule(s, range(lo, hi + 1), lo, hi)[2]
    for rho in RHOS:
        runs = ppv_budget_schedule(s, lo, hi, rho, fd["tau"], fd["cap"], ft)
        n = len(runs)
        r = {"seq": s, "frames": hi - lo + 1, "rho": round(rho, 4), "calls": n, "fixed_f1": fixed,
             "ppv_f1": eval_schedule(s, runs, lo, hi)[2],
             "periodic_f1": eval_schedule(s, periodic_schedule(lo, hi, n), lo, hi)[2],
             "framediff_f1": eval_schedule(s, framediff_schedule(s, lo, hi, n), lo, hi)[2]}
        rf = [eval_schedule(s, random_schedule(lo, hi, n, sd), lo, hi)[2] for sd in range(N_RANDOM)]
        r["random_mean"], r["random_std"] = float(np.mean(rf)), float(np.std(rf))
        r["ppv_beats_random"] = int(sum(r["ppv_f1"] > x for x in rf))
        lrows.append(r)
        print(f"{s} rho={rho:.3f} calls={n:>3}/{hi-lo+1} | PPV {r['ppv_f1']:.4f} "
              f"periodic {r['periodic_f1']:.4f} fdiff {r['framediff_f1']:.4f} "
              f"rand {r['random_mean']:.4f} fixed {fixed:.4f}")
loso = pd.DataFrame(lrows)
loso["d_periodic"] = loso.ppv_f1 - loso.periodic_f1
loso["d_framediff"] = loso.ppv_f1 - loso.framediff_f1
loso["d_random"] = loso.ppv_f1 - loso.random_mean
loso.to_csv(LOSO_FILE, index=False)

def paired2(d):
    d = np.asarray(d); d = d[np.abs(d) > 1e-12]
    out = {"n": int(len(d)), "wins": int((d > 0).sum()), "losses": int((d < 0).sum()),
           "mean": float(d.mean()) if len(d) else float("nan")}
    out["p"] = float(wilcoxon(d, alternative="greater").pvalue) if len(d) >= 6 else float("nan")
    return out
LSTATS = {k: paired2(loso[c]) for k, c in
          [("vs_periodic", "d_periodic"), ("vs_framediff", "d_framediff"), ("vs_random", "d_random")]}
print("\nLOSO paired one-sided Wilcoxon (PPV better than ...):")
for k, v in LSTATS.items():
    print(" ", k, v)
json.dump(LSTATS, open(os.path.join(LOSO_DIR, "loso_stats.json"), "w"), indent=1)

fig, axes = plt.subplots(2, 4, figsize=(16.8, 6.4), squeeze=False)
for ax, s in zip(axes.ravel(), SEQS):
    d = loso[loso.seq == s].sort_values("calls"); x = 100 * d.calls / d.frames
    ax.plot(x, d.ppv_f1, "o-", color="#d62728", label="PPV-Lite (LOSO, budgeted)")
    ax.plot(x, d.periodic_f1, "s--", color="#1f77b4", label="Periodic")
    ax.plot(x, d.framediff_f1, "^:", color="#2ca02c", label="Frame-diff")
    ax.errorbar(x, d.random_mean, yerr=d.random_std, fmt="d-", color="#7f7f7f", alpha=.8, label="Random")
    ax.axhline(d.fixed_f1.iloc[0], color="black", lw=1, label="Fixed")
    ax.set_title(s.replace("-FRCNN", ""), fontsize=10)
    ax.set_xlabel("Detector calls (% of frames)"); ax.set_ylabel("F1 (IoU 0.5)")
for ax in axes.ravel()[len(SEQS):]:
    ax.axis("off")
axes.ravel()[0].legend(fontsize=7, loc="lower right")
fig.tight_layout()
fig.savefig(os.path.join(LOSO_DIR, "fig_loso.pdf")); fig.savefig(os.path.join(LOSO_DIR, "fig_loso.png"), dpi=200)
print("CELL 7 done")



# =====================================================================
# EXTRA DATASETS: does PPV-Lite beat periodic placement on new footage?
#
# Run in the SAME Kaggle session, after cell 1 and the option-1 cell
# (they reload from /kaggle/working/ppv_v2 in a few minutes).
#
# Add one or both datasets with "Add Input" before running:
#   * UA-DETRAC (traffic, vehicles): e.g. "bratjay/ua-detrac-orig"
#     (needs MVI_xxxxx image folders + MVI_xxxxx.xml annotations)
#   * MOT20 or any MOT-format set with img1/ + gt/gt.txt
#     (MOT20, SportsMOT, DanceTrack ...). MOT16/MOT17 are skipped.
#
# Protocol: the tree is trained on ALL seven MOT17 sequences, tau and the
# cap C are tuned on MOT17 only, and the frozen scheduler is tested once
# on every new sequence (frames 101-600). Nothing from the new datasets is
# used for training or tuning.
# Paste everything after "=== EXTRA DATASETS SUMMARY ===" into the chat.
# =====================================================================
import xml.etree.ElementTree as ET

_needed = ["Seq", "eval_schedule", "periodic_schedule", "random_schedule", "framediff_schedule",
           "ppv_budget_schedule", "FastTree", "feats5", "FEATS5", "LAB", "RHOS",
           "TAU_GRID", "CAP_GRID", "paired2", "model", "S", "DATA", "SEQS", "win2"]
_missing = [n for n in _needed if n not in globals()]
if _missing:
    raise RuntimeError("Run cell 1 and the option-1 cell first in this session. Missing: " + ", ".join(_missing))

EXT_DIR = os.path.join(OUT, "ext")
EXTRA_ROOTS = [INPUT_ROOT] + [r for r in ["/kaggle/ext_data"] if os.path.isdir(r)]   # Add Input + downloaded data
os.makedirs(EXT_DIR, exist_ok=True)
MAX_PER_DATASET = 8          # sequences per dataset (spread over the list)
EXT_FRAMES = 600
PERSON, VEHICLE = {0}, {2, 3, 5, 7}     # COCO: person | car, motorcycle, bus, truck

# ---------------------------------------------------------------- discovery
def spread(items, k):
    items = sorted(items)
    if len(items) <= k:
        return items
    idx = np.linspace(0, len(items) - 1, k).round().astype(int)
    return [items[i] for i in idx]

ext = []   # (dataset, seq_name, sorted image files, gt_loader, coco_classes)

# MOT-format sequences (img1 + gt/gt.txt), excluding MOT16/MOT17
mot_like = {}
for img_dir in [d for r in EXTRA_ROOTS for d in glob.glob(os.path.join(r, "**", "img1"), recursive=True)]:
    seq = os.path.basename(os.path.dirname(img_dir))
    gt = os.path.join(os.path.dirname(img_dir), "gt", "gt.txt")
    if not os.path.exists(gt) or seq.startswith(("MOT17", "MOT16")):
        continue
    ds = seq.split("-")[0] if "-" in seq else os.path.basename(os.path.dirname(os.path.dirname(img_dir)))
    mot_like.setdefault(ds, {})
    mot_like[ds].setdefault(seq, (img_dir, gt))

def mot_gt_loader(gt_path):
    def load():
        df = pd.read_csv(gt_path, header=None)
        out = {}
        for r in df.itertuples(index=False):
            f, x, y, w, h = int(r[0]), r[2], r[3], r[4], r[5]
            flag = r[6] if len(r) > 6 else 1
            cls = int(r[7]) if len(r) > 7 and not pd.isna(r[7]) else 1
            if flag <= 0 or w <= 0 or h <= 0 or cls != 1:
                continue
            out.setdefault(f, []).append([x, y, x + w, y + h])
        return {k: np.asarray(v, np.float32) for k, v in out.items()}, []
    return load

for ds, seqs in mot_like.items():
    for seq in spread(list(seqs), MAX_PER_DATASET):
        img_dir, gt = seqs[seq]
        files = sorted(glob.glob(os.path.join(img_dir, "*.jpg")))
        if len(files) >= 200:
            ext.append((ds, seq, files, mot_gt_loader(gt), PERSON))

# UA-DETRAC: MVI_xxxxx.xml + folder MVI_xxxxx with img*.jpg
xmls = {os.path.splitext(os.path.basename(x))[0]: x
        for r in EXTRA_ROOTS for x in glob.glob(os.path.join(r, "**", "MVI_*.xml"), recursive=True)}
imgdirs = {}
for d in [d for r in EXTRA_ROOTS for d in glob.glob(os.path.join(r, "**", "MVI_*"), recursive=True)]:
    if os.path.isdir(d):
        imgdirs.setdefault(os.path.basename(d), d)

def detrac_gt_loader(xml_path):
    def load():
        root = ET.parse(xml_path).getroot()
        ign = []
        for b in root.iter("ignored_region"):
            for box in b.iter("box"):
                l, t = float(box.get("left")), float(box.get("top"))
                ign.append([l, t, l + float(box.get("width")), t + float(box.get("height"))])
        out = {}
        for fr in root.iter("frame"):
            f = int(fr.get("num"))
            for box in fr.iter("box"):
                l, t = float(box.get("left")), float(box.get("top"))
                out.setdefault(f, []).append([l, t, l + float(box.get("width")), t + float(box.get("height"))])
        return {k: np.asarray(v, np.float32) for k, v in out.items()}, ign
    return load

detrac = sorted(set(xmls) & set(imgdirs))
for seq in spread(detrac, MAX_PER_DATASET):
    files = sorted(glob.glob(os.path.join(imgdirs[seq], "*.jpg")))
    if len(files) >= 200:
        ext.append(("UA-DETRAC", seq, files, detrac_gt_loader(xmls[seq]), VEHICLE))

print("New sequences found:")
for ds, seq, files, _, cl in ext:
    print(f"  {ds:12s} {seq:20s} {len(files)} frames  classes={sorted(cl)}")
if not ext:
    raise RuntimeError("No new dataset found. Add MOT20 or UA-DETRAC with 'Add Input' and rerun.")

# ---------------------------------------------------------------- caches
def centre_in(boxes, regions):
    if len(boxes) == 0 or not regions:
        return np.zeros(len(boxes), bool)
    cx = (boxes[:, 0] + boxes[:, 2]) / 2; cy = (boxes[:, 1] + boxes[:, 3]) / 2
    inside = np.zeros(len(boxes), bool)
    for l, t, r, b in regions:
        inside |= (cx >= l) & (cx <= r) & (cy >= t) & (cy <= b)
    return inside

def build_ext(ds, seq, files, gt_loader, classes):
    path = os.path.join(EXT_DIR, f"{ds}_{seq}_cache.pkl".replace("/", "_"))
    if os.path.exists(path):
        with open(path, "rb") as f:
            c = pickle.load(f)
        if c.get("complete"):
            return c
    gt, ignored = gt_loader()
    files = files[:EXT_FRAMES]
    c = {"seq": seq, "n": len(files), "det": {}, "small": {}, "flow": {}, "complete": False}
    # drop ground truth inside ignored regions as well, so both sides are treated alike
    c["gt"] = {f: b[~centre_in(b, ignored)] for f, b in gt.items()}
    batch, ids = [], []
    for i, fp in enumerate(files, start=1):
        img = cv2.imread(fp)
        if img is None:
            raise FileNotFoundError(fp)
        if i == 1:
            c["H"], c["W"] = img.shape[:2]
        g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        c["small"][i] = cv2.resize(g, SMALL, interpolation=cv2.INTER_AREA)
        c["flow"][i] = cv2.resize(g, None, fx=FLOW_SCALE, fy=FLOW_SCALE, interpolation=cv2.INTER_AREA)
        if FAKE:
            FAKE_GT_LOOKUP[id(img)] = c["gt"].get(i, np.zeros((0, 4), np.float32))
        batch.append(img); ids.append(i)
        if len(batch) == 16 or i == len(files):
            res = model(batch, verbose=False, device=0)
            for fid, r in zip(ids, res):
                if r.boxes is None or len(r.boxes) == 0:
                    b = np.zeros((0, 4), np.float32); cf = np.zeros(0, np.float32)
                else:
                    b = r.boxes.xyxy.detach().cpu().numpy().astype(np.float32)
                    cf = r.boxes.conf.detach().cpu().numpy().astype(np.float32)
                    k = r.boxes.cls.detach().cpu().numpy().astype(np.int32)
                    keep = np.isin(k, list(classes | ({0} if FAKE else set())))
                    b, cf = b[keep], cf[keep]
                    out = centre_in(b, ignored)
                    b, cf = b[~out], cf[~out]
                c["det"][fid] = {"boxes": b, "conf": cf}
            batch, ids = [], []
    c["complete"] = True
    with open(path, "wb") as f:
        pickle.dump(c, f, protocol=pickle.HIGHEST_PROTOCOL)
    return c

t0 = time.time()
EXT_KEYS = []
for ds, seq, files, loader, cl in ext:
    key = f"{ds}/{seq}"
    DATA[key] = build_ext(ds, seq, files, loader, cl)
    S[key] = Seq(DATA[key])
    EXT_KEYS.append(key)
    print(f"  cached {key}: {DATA[key]['n']} frames {DATA[key]['W']}x{DATA[key]['H']} | {time.time()-t0:.0f}s")

# ---------------------------------------------------------------- final tree on all MOT17
FINAL = os.path.join(EXT_DIR, "final_tree_all_mot17.pkl")
if os.path.exists(FINAL):
    with open(FINAL, "rb") as f:
        fin = pickle.load(f)
else:
    df = pd.concat([LAB[s] for s in SEQS])
    clf = DecisionTreeClassifier(max_depth=3, min_samples_leaf=20, class_weight="balanced", random_state=42)
    clf.fit(df[FEATS5].values, df["beneficial"].values)
    ft = FastTree(clf); best = None
    for tau in TAU_GRID:
        for cap in CAP_GRID:
            gains = []
            for s in SEQS:
                lo, hi = win2(s)
                for rho in RHOS:
                    runs = ppv_budget_schedule(s, lo, hi, rho, tau, cap, ft)
                    gains.append(eval_schedule(s, runs, lo, hi)[2] -
                                 eval_schedule(s, periodic_schedule(lo, hi, len(runs)), lo, hi)[2])
            g = float(np.mean(gains))
            if best is None or g > best[2]:
                best = (tau, cap, g)
    fin = {"clf": clf, "tau": best[0], "cap": best[1], "mot17_gain": best[2],
           "importance": dict(zip(FEATS5, clf.feature_importances_.round(4)))}
    with open(FINAL, "wb") as f:
        pickle.dump(fin, f)
print(f"Final tree (all MOT17): tau={fin['tau']} cap={fin['cap']} | importance {fin['importance']}")
FT = FastTree(fin["clf"])

# ---------------------------------------------------------------- evaluation
EXT_FILE = os.path.join(EXT_DIR, "ext_results.csv")
erows = []
for key in EXT_KEYS:
    n = DATA[key]["n"]; lo, hi = 101, min(600, n)
    fixed = eval_schedule(key, range(lo, hi + 1), lo, hi)[2]
    for rho in RHOS:
        runs = ppv_budget_schedule(key, lo, hi, rho, fin["tau"], fin["cap"], FT)
        k = len(runs)
        r = {"dataset": key.split("/")[0], "seq": key.split("/")[1], "frames": hi - lo + 1,
             "rho": round(rho, 4), "calls": k, "fixed_f1": fixed,
             "ppv_f1": eval_schedule(key, runs, lo, hi)[2],
             "periodic_f1": eval_schedule(key, periodic_schedule(lo, hi, k), lo, hi)[2],
             "framediff_f1": eval_schedule(key, framediff_schedule(key, lo, hi, k), lo, hi)[2]}
        rf = [eval_schedule(key, random_schedule(lo, hi, k, sd), lo, hi)[2] for sd in range(N_RANDOM)]
        r["random_mean"], r["random_std"] = float(np.mean(rf)), float(np.std(rf))
        erows.append(r)
        print(f"{key} rho={rho:.3f} calls={k}/{hi-lo+1} | PPV {r['ppv_f1']:.4f} periodic {r['periodic_f1']:.4f} "
              f"fdiff {r['framediff_f1']:.4f} rand {r['random_mean']:.4f} fixed {fixed:.4f}")
er = pd.DataFrame(erows)
er["d_periodic"] = er.ppv_f1 - er.periodic_f1
er["d_framediff"] = er.ppv_f1 - er.framediff_f1
er["d_random"] = er.ppv_f1 - er.random_mean
er.to_csv(EXT_FILE, index=False)

from scipy import stats as _st
def ci(x):
    x = np.asarray(x); m = x.mean()
    if len(x) < 2:
        return m, float("nan"), float("nan")
    h = _st.t.ppf(.975, len(x) - 1) * x.std(ddof=1) / np.sqrt(len(x))
    return m, m - h, m + h

print("\n=== EXTRA DATASETS SUMMARY ===")
print(f"Tree trained on all 7 MOT17 sequences; tau={fin['tau']} cap={fin['cap']}; importance {fin['importance']}")
pd.set_option("display.width", 250); pd.set_option("display.max_columns", 30)
print(er.round(4).to_string(index=False))
for name, d in [("ALL NEW DATA", er)] + [(ds, er[er.dataset == ds]) for ds in er.dataset.unique()]:
    print(f"\n--- {name} ({len(d)} schedules) ---")
    for col in ["d_periodic", "d_framediff", "d_random"]:
        m, l, h = ci(d[col])
        print(f"  {col:12s} {paired2(d[col])}  95%CI [{l:+.4f}, {h:+.4f}]")
print("\nPer sequence (mean over budgets):")
print(er.groupby(["dataset", "seq"])[["d_periodic", "d_framediff", "d_random"]].mean().round(4).to_string())




# =====================================================================
# REVISION EXPERIMENTS  (reviewer comments 1-25, required A-H)
#   R0  call-rate verification against the token-bucket bound   (H, 7)
#   R1  label statistics and edge cases of frame-level F1        (3, 17)
#   R2  feature ablation incl. no-controller                     (B, 9)
#   R3  classifier / regression ablation                         (C, 10, 3)
#   R4  training vs inference feature states, dense gaps, DAgger (8)
#   R5  F1 at IoU 0.5/0.6/0.75, AP50, AP50:95                     (D, 15)
#   R6  random baseline spread (mean, sd, min, max)              (18)
#   R7  sequence-level statistics, cluster bootstrap, TOST       (E, 5, 6)
#   R8  MOT20 per sequence and without the low-F1 sequences      (17)
#   R9  online timing of the FINAL system, 6 budgets, energy     (A, F, 1, 13, 14)
#   R10 detector-cost regimes: yolo11n (GPU) and yolo11m (CPU)   (11, 19)
# Everything checkpoints to /kaggle/working/ppv_v2/revision.
# At the end: download /kaggle/working/ppv_v2/revision.zip and upload it
# to the chat (or paste everything after "=== REVISION SUMMARY ===").
# =====================================================================
import itertools, shutil
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import balanced_accuracy_score
from sklearn.model_selection import cross_val_score
from scipy.stats import ks_2samp, ttest_1samp, wilcoxon
from scipy import stats as _st

REV = os.path.join(OUT, "revision"); os.makedirs(REV, exist_ok=True)
RUN_TIMING, RUN_NANO, RUN_CPU = True, True, True      # set False to skip the first timing set
SKIP_TIMING = []          # e.g. ["MOT17-13-FRCNN"] if one sequence keeps hanging
TIME_LO, TIME_HI, REPEATS = 101, 400, 3          # 300-frame timing window, 3 repeats
GT_MAX = 30                                      # gaps tabulated for fast scheduling
FIDX = {f: i for i, f in enumerate(FEATS5)}
def ck(name): return os.path.join(REV, name)
def log(*a): print(*a, flush=True)
T_REV = time.time()

# ---------------------------------------------------------------- feature tables
_ENT, _MU, _CM = {}, {}, {}
def _pf(seq):
    if seq in _ENT: return
    sq, n = S[seq], DATA[seq]["n"]
    _ENT[seq] = {t: sq.entropy(t) for t in range(1, n + 1)}
    _MU[seq] = {t: float(DATA[seq]["small"][t].mean() / 255.0) for t in range(1, n + 1)}
    _CM[seq] = {t: (float(DATA[seq]["det"][t]["conf"].mean()) if len(DATA[seq]["det"][t]["conf"]) else 0.0)
                for t in range(1, n + 1)}
FM = {}
def featmat(seq):
    """X[t, g] = the five features seen at frame t when the last detector frame is t-g."""
    if seq in FM: return FM[seq]
    _pf(seq); sq, n = S[seq], DATA[seq]["n"]
    X = np.full((n + 1, GT_MAX + 1, 5), np.nan)
    for t in range(2, n + 1):
        for g in range(1, min(GT_MAX, t - 1) + 1):
            k = t - g
            X[t, g] = feats5(sq, t, k)
    FM[seq] = X
    return X

def table(seq, sc, cols):
    X = featmat(seq); flat = X.reshape(-1, 5); ok = ~np.isnan(flat[:, 0])
    out = np.full(flat.shape[0], np.nan)
    if ok.any(): out[ok] = sc(flat[ok][:, cols])
    return out.reshape(X.shape[0], X.shape[1])

def sched_tab(seq, lo, hi, rho, tau, cap, tab, fb, states=None):
    """Token-bucket scheduler (identical to ppv_budget_schedule) on a score table."""
    k, c, runs = lo - 1, 0.0, []
    for t in range(lo, hi + 1):
        c += rho
        if c >= 1.0:
            if c >= cap: run = True
            else:
                g = t - k
                s = tab[t, g] if g <= GT_MAX else fb(seq, t, k)
                if states is not None: states.append((t, k))
                run = s >= tau
            if run:
                runs.append(t); k = t; c -= 1.0
    return runs

def sched_thr(seq, lo, hi, tau, tab, fb):
    """No budget controller: plain threshold rule on the same score."""
    k, runs = lo - 1, []
    for t in range(lo, hi + 1):
        g = t - k
        s = tab[t, g] if g <= GT_MAX else fb(seq, t, k)
        if s >= tau:
            runs.append(t); k = t
    return runs

def make_fb(sc, cols):
    return lambda seq, t, k: float(sc(np.asarray([feats5(S[seq], t, k)])[:, cols])[0])

_PER = {}
def per_f1(seq, lo, hi, n):
    key = (seq, lo, hi, n)
    if key not in _PER: _PER[key] = eval_schedule(seq, periodic_schedule(lo, hi, n), lo, hi)[2]
    return _PER[key]

# ---------------------------------------------------------------- R0 call-rate verification
log("\n[R0] call-rate verification")
rows = []
for name, df_ in [("MOT17 LOSO", loso)] + ([("MOT20", er[er.dataset.astype(str).str.startswith("MOT20")])] if "er" in globals() else []):
    for r in df_.itertuples(index=False):
        tgt = r.rho * r.frames
        rows.append({"set": name, "seq": r.seq, "rho": r.rho, "frames": r.frames, "target": tgt,
                     "calls": r.calls, "dev": r.calls - tgt})
CR = pd.DataFrame(rows)
CR["cap"] = [FOLDS[q]["cap"] if q in FOLDS else (fin["cap"] if "fin" in globals() else 2.0) for q in CR.seq]
CR["within_bound"] = (CR.dev <= 1e-9) & (CR.dev > -CR.cap)
# max gap between consecutive calls, from the actual LOSO schedules
gaps = []
for s in SEQS:
    fd = FOLDS[s]; ft = FastTree(fd["clf"]); lo, hi = win2(s)
    for rho in RHOS:
        runs = ppv_budget_schedule(s, lo, hi, rho, fd["tau"], fd["cap"], ft)
        g = np.diff([lo - 1] + runs)
        gaps.append({"seq": s, "rho": round(rho, 4), "cap": fd["cap"], "max_gap": int(g.max()),
                     "bound": int(np.ceil(fd["cap"] / rho))})
GAPS = pd.DataFrame(gaps)
CR.to_csv(ck("R0_callrate.csv"), index=False); GAPS.to_csv(ck("R0_maxgap.csv"), index=False)

# ---------------------------------------------------------------- R1 label statistics
log("[R1] label statistics")
def label_rows(key, lo=2, hi=None, gaps=LABEL_GAPS):
    sq = S[key]; hi = hi or DATA[key]["n"]; out = []
    for t in range(max(2, lo), hi + 1):
        g_t = len(sq.gt_of(t)); nd = len(DATA[key]["det"][t]["boxes"])
        _, _, fr = prf(*sq.det_counts(t))
        for g in gaps:
            k = t - g
            if k < 1: continue
            npb = len(sq.propagate(k, t))
            _, _, fp_ = prf(*sq.prop_counts(k, t))
            out.append((g_t, nd, npb, fr - fp_))
    return np.asarray(out, float)
lrows = []
for key in SEQS + (EXT_KEYS if "EXT_KEYS" in globals() else []):
    if key in SEQS:
        L = LAB[key]; d = L.delta.values
        a = label_rows(key, gaps=(1,)) ; empty_gt = float((a[:, 0] == 0).mean())
    else:
        a = label_rows(key, lo=101, hi=min(600, DATA[key]["n"])); d = a[:, 3]
        empty_gt = float((a[:, 0] == 0).mean())
    lrows.append({"seq": key, "rows": len(d), "pos": float((d > 0).mean()), "neg": float((d < 0).mean()),
                  "tie": float((d == 0).mean()), "frames_no_gt": empty_gt,
                  "mean_abs_delta": float(np.abs(d).mean()),
                  "pos_mean": float(d[d > 0].mean()) if (d > 0).any() else 0.0,
                  "neg_mean": float(d[d < 0].mean()) if (d < 0).any() else 0.0,
                  "q90_abs": float(np.quantile(np.abs(d), .9)),
                  "share_pos_below_0.01": float(((d > 0) & (d < 0.01)).sum() / max(1, (d > 0).sum()))})
LST = pd.DataFrame(lrows); LST.to_csv(ck("R1_label_stats.csv"), index=False)

# ---------------------------------------------------------------- model zoo
def make_model(name):
    if name in ("dt3", "dt3_wt"):
        return DecisionTreeClassifier(max_depth=3, min_samples_leaf=20, class_weight="balanced", random_state=42)
    if name == "dt3_reg":
        return DecisionTreeRegressor(max_depth=3, min_samples_leaf=20, random_state=42)
    if name == "logreg":
        return make_pipeline(StandardScaler(), LogisticRegression(class_weight="balanced", max_iter=2000))
    if name == "rf":
        return RandomForestClassifier(n_estimators=50, max_depth=4, min_samples_leaf=20,
                                      class_weight="balanced", n_jobs=-1, random_state=42)
    if name == "gbt":
        return HistGradientBoostingClassifier(max_depth=3, max_iter=100, learning_rate=0.1, random_state=42)
    if name == "mlp":
        return make_pipeline(StandardScaler(), MLPClassifier((16, 8), max_iter=300, early_stopping=True,
                                                             random_state=42))
    raise ValueError(name)

def fit_model(name, df, cols):
    X = df[[FEATS5[i] for i in cols]].values; y = df.beneficial.values; d = df.delta.values
    m = make_model(name)
    if name == "dt3_reg": m.fit(X, d)
    elif name == "dt3_wt": m.fit(X, y, sample_weight=np.abs(d) + 1e-3)
    elif name == "gbt":
        w = np.where(y == 1, 0.5 / max(y.mean(), 1e-6), 0.5 / max(1 - y.mean(), 1e-6)); m.fit(X, y, sample_weight=w)
    else: m.fit(X, y)
    return m

def scorer(name, m):
    if name == "dt3_reg": return lambda X: m.predict(X)
    if name in ("dt3", "dt3_wt"):
        ft = FastTree(m); return lambda X: np.fromiter((ft(x) for x in X), float, len(X)) if len(X) < 64 else m.predict_proba(X)[:, 1]
    return lambda X: m.predict_proba(X)[:, 1]

TAUS = {"dt3_reg": [-0.01, -0.005, 0.0, 0.005, 0.01, 0.02]}

def tune(train, tabs, fb, taus):
    best = None
    for tau in taus:
        for cap in CAP_GRID:
            gains = []
            for s in train:
                lo, hi = win2(s)
                for rho in RHOS:
                    runs = sched_tab(s, lo, hi, rho, tau, cap, tabs[s], fb)
                    gains.append(eval_schedule(s, runs, lo, hi)[2] - per_f1(s, lo, hi, len(runs)))
            g = float(np.mean(gains))
            if best is None or g > best[2]: best = (tau, cap, g)
    return best

def model_bytes(m):
    try: return len(pickle.dumps(m))
    except Exception: return -1

def latency_us(sc, cols, model=None, name=""):
    x = np.asarray([[2, 4.5, 0.0, 0.6, 0.02]])[:, cols]
    if name == "dt3_reg":
        t_ = model.tree_; L, R, F, TH, V = t_.children_left, t_.children_right, t_.feature, t_.threshold, t_.value[:, 0, 0]
        def walk(z):
            n = 0
            while L[n] != -1: n = L[n] if z[F[n]] <= TH[n] else R[n]
            return V[n]
        a = time.perf_counter()
        for _ in range(2000): walk(x[0])
        return (time.perf_counter() - a) / 2000 * 1e6
    if name in ("dt3", "dt3_wt"):
        ft = FastTree(model); a = time.perf_counter()
        for _ in range(2000): ft(x[0])
        return (time.perf_counter() - a) / 2000 * 1e6
    a = time.perf_counter()
    for _ in range(300): sc(x)
    return (time.perf_counter() - a) / 300 * 1e6

def run_variant(tag, model_name="dt3", feats=FEATS5, controller=True, train_fn=None):
    path = ck(f"var_{tag}.csv")
    if os.path.exists(path): return pd.read_csv(path)
    cols = [FIDX[f] for f in feats]; rows = []
    for test in SEQS:
        train = [s for s in SEQS if s != test]
        if train_fn is None:
            m = fit_model(model_name, pd.concat([LAB[s] for s in train]), cols)
            sc = scorer(model_name, m); fb = make_fb(sc, cols)
            tabs = {s: table(s, sc, cols) for s in SEQS}
        else:
            m, sc, fb, tabs = train_fn(test, train, cols)
        # classification quality on the unseen sequence's counterfactual labels
        Lt = LAB[test]; st = sc(Lt[[FEATS5[i] for i in cols]].values)
        thr = 0.0 if model_name == "dt3_reg" else 0.5
        acc = float(((st > thr).astype(int) == Lt.beneficial.values).mean())
        bacc = float(balanced_accuracy_score(Lt.beneficial.values, (st > thr).astype(int)))
        auc = float(roc_auc_score(Lt.beneficial.values, st)) if Lt.beneficial.nunique() > 1 else float("nan")
        lo, hi = win2(test); fixed = eval_schedule(test, range(lo, hi + 1), lo, hi)[2]
        if controller:
            tau, cap, g = tune(train, tabs, fb, TAUS.get(model_name, TAU_GRID))
            for rho in RHOS:
                runs = sched_tab(test, lo, hi, rho, tau, cap, tabs[test], fb)
                f = eval_schedule(test, runs, lo, hi)[2]; n = len(runs)
                rows.append({"variant": tag, "seq": test, "rho": round(rho, 4), "frames": hi - lo + 1,
                             "target": rho * (hi - lo + 1), "calls": n, "tau": tau, "cap": cap,
                             "ppv_f1": f, "periodic_f1": per_f1(test, lo, hi, n), "fixed_f1": fixed,
                             "acc": acc, "bacc": bacc, "auc": auc})
        else:
            # tau per budget chosen on the training sequences so the mean call rate is closest to rho
            cand = np.unique(np.concatenate([tabs[s][~np.isnan(tabs[s])] for s in train]))
            if len(cand) > 60: cand = np.quantile(cand, np.linspace(0, 1, 60))
            for rho in RHOS:
                best = None
                for tau in cand:
                    rates = []
                    for s in train:
                        l2, h2 = win2(s); rates.append(len(sched_thr(s, l2, h2, tau, tabs[s], fb)) / (h2 - l2 + 1))
                    e = abs(np.mean(rates) - rho)
                    if best is None or e < best[1]: best = (tau, e)
                runs = sched_thr(test, lo, hi, best[0], tabs[test], fb); n = len(runs)
                rows.append({"variant": tag, "seq": test, "rho": round(rho, 4), "frames": hi - lo + 1,
                             "target": rho * (hi - lo + 1), "calls": n, "tau": best[0], "cap": np.nan,
                             "ppv_f1": eval_schedule(test, runs, lo, hi)[2],
                             "periodic_f1": per_f1(test, lo, hi, n), "fixed_f1": fixed,
                             "acc": acc, "bacc": bacc, "auc": auc})
        log(f"   {tag:12s} fold {test}: auc {auc:.3f} | {time.time()-T_REV:.0f}s")
    out = pd.DataFrame(rows); out["d_periodic"] = out.ppv_f1 - out.periodic_f1
    out["model_bytes"] = model_bytes(m); out["latency_us"] = latency_us(sc, cols, m, model_name)
    out.to_csv(path, index=False)
    return out

# ---------------------------------------------------------------- R2 feature ablation
log("[R2] feature ablation")
FEAT_VARIANTS = {
    "full5": FEATS5,
    "gap_only": ["gap"],
    "gap+scene": ["gap", "scene_diff"],
    "no_entropy": [f for f in FEATS5 if f != "entropy"],
    "no_brightness": [f for f in FEATS5 if f != "brightness_change"],
    "no_confidence": [f for f in FEATS5 if f != "mean_confidence_previous"],
    "scene_only": ["scene_diff"],
}
ABL = []
for tag, fs in FEAT_VARIANTS.items():
    ABL.append(run_variant(tag, "dt3", fs))
ABL.append(run_variant("no_controller", "dt3", FEATS5, controller=False))
ABL = pd.concat(ABL)
chk = ABL[ABL.variant == "full5"].merge(loso[["seq", "rho", "ppv_f1"]], on=["seq", "rho"], suffixes=("", "_loso"))
log(f"   check full5 reproduces LOSO: max |diff| = {np.abs(chk.ppv_f1 - chk.ppv_f1_loso).max():.2e}")

# ---------------------------------------------------------------- R3 classifier ablation
log("[R3] classifier ablation")
CLS = [ABL[ABL.variant == "full5"].assign(variant="dt3")]
for nm in ["logreg", "rf", "gbt", "mlp", "dt3_reg", "dt3_wt"]:
    CLS.append(run_variant(nm, nm, FEATS5))
CLS = pd.concat(CLS)

# ---------------------------------------------------------------- R4 distribution shift
log("[R4] training vs inference states")
def states_of(seq, clf, tau, cap):
    ft = FastTree(clf); sc = lambda X: np.fromiter((ft(x) for x in X), float, len(X))
    tab = table(seq, sc, list(range(5))); fb = make_fb(sc, list(range(5)))
    lo, hi = win2(seq); st = []
    for rho in RHOS: sched_tab(seq, lo, hi, rho, tau, cap, tab, fb, states=st)
    return st
srows, leaf_rows = [], []
for s in SEQS:
    fd = FOLDS[s]
    st = states_of(s, fd["clf"], fd["tau"], fd["cap"])
    Xi = np.asarray([feats5(S[s], t, k) for t, k in st])
    Xo = LAB[s][FEATS5].values                                        # offline rows, same sequence
    Xtr = pd.concat([LAB[x] for x in SEQS if x != s])[FEATS5].values  # offline rows, training sequences
    r = {"seq": s, "n_inference_states": len(Xi),
         "gap_outside_training_set": float(np.mean(~np.isin(Xi[:, 0], LABEL_GAPS)))}
    for j, f in enumerate(FEATS5):
        r[f"ks_{f}"] = float(ks_2samp(Xi[:, j], Xo[:, j]).statistic)
    for j, f in enumerate(FEATS5[1:], start=1):        # content features given the same gap mix
        r[f"ks_nogap_{f}"] = float(ks_2samp(Xi[:, j], Xo[np.isin(Xo[:, 0], np.unique(Xi[:, 0])), j]).statistic)
    rng = np.random.default_rng(0)
    m = min(len(Xi), len(Xo)); a = Xi[rng.choice(len(Xi), m, replace=False)]; b = Xo[rng.choice(len(Xo), m, replace=False)]
    Xd = np.vstack([a, b]); yd = np.r_[np.ones(m), np.zeros(m)]
    r["domain_auc_all"] = float(cross_val_score(HistGradientBoostingClassifier(max_depth=3, max_iter=100),
                                                Xd, yd, cv=5, scoring="roc_auc").mean())
    r["domain_auc_no_gap"] = float(cross_val_score(HistGradientBoostingClassifier(max_depth=3, max_iter=100),
                                                   Xd[:, 1:], yd, cv=5, scoring="roc_auc").mean())
    li, lt = fd["clf"].apply(Xi), fd["clf"].apply(Xtr)
    leaves = np.union1d(li, lt)
    pi = np.array([(li == l).mean() for l in leaves]); pt = np.array([(lt == l).mean() for l in leaves])
    r["leaf_tv_distance"] = float(0.5 * np.abs(pi - pt).sum())
    r["inference_in_empty_leaf"] = float(np.isin(li, leaves[pt == 0]).mean())
    srows.append(r)
SHIFT = pd.DataFrame(srows); SHIFT.to_csv(ck("R4_shift.csv"), index=False)

# dense fixed gaps (1..20) and DAgger-style aggregation
DENSE_GAPS = tuple(range(1, 21))
_LD = {}
def labels_dense(seq):
    if seq in _LD: return _LD[seq]
    p = ck(f"labels_dense_{seq}.csv")
    if os.path.exists(p): _LD[seq] = pd.read_csv(p); return _LD[seq]
    sq, rows, n = S[seq], [], DATA[seq]["n"]
    for t in range(2, n + 1):
        _, _, fr = prf(*sq.det_counts(t))
        for g in DENSE_GAPS:
            k = t - g
            if k < 1: continue
            _, _, fp_ = prf(*sq.prop_counts(k, t))
            rows.append([seq, t, *feats5(sq, t, k), int(fr > fp_), fr - fp_])
    _LD[seq] = pd.DataFrame(rows, columns=["seq", "frame"] + FEATS5 + ["beneficial", "delta"])
    _LD[seq].to_csv(p, index=False)
    return _LD[seq]

def label_states(seq, st):
    sq, rows = S[seq], []
    for t, k in st:
        _, _, fr = prf(*sq.det_counts(t)); _, _, fp_ = prf(*sq.prop_counts(k, t))
        rows.append([seq, t, *feats5(sq, t, k), int(fr > fp_), fr - fp_])
    return pd.DataFrame(rows, columns=["seq", "frame"] + FEATS5 + ["beneficial", "delta"])

def _fit_tables(df, cols):
    m = fit_model("dt3", df, cols); sc = scorer("dt3", m); fb = make_fb(sc, cols)
    return m, sc, fb, {s: table(s, sc, cols) for s in SEQS}

def train_dense(test, train, cols):
    return _fit_tables(pd.concat([labels_dense(s) for s in train]), cols)

def train_dagger(test, train, cols, rounds=2):
    data = [LAB[s] for s in train]
    m, sc, fb, tabs = _fit_tables(pd.concat(data), cols)
    for _ in range(rounds):
        tau, cap, _g = tune(train, tabs, fb, TAU_GRID)
        for s in train:
            lo, hi = win2(s); st = []
            for rho in RHOS: sched_tab(s, lo, hi, rho, tau, cap, tabs[s], fb, states=st)
            data.append(label_states(s, st))
        m, sc, fb, tabs = _fit_tables(pd.concat(data), cols)
    return m, sc, fb, tabs

SHIFT_VAR = pd.concat([ABL[ABL.variant == "full5"].assign(variant="offline_gaps(paper)"),
                       run_variant("dense_gaps_1_20", "dt3", FEATS5, train_fn=train_dense),
                       run_variant("dagger_2rounds", "dt3", FEATS5, train_fn=train_dagger)])

# ---------------------------------------------------------------- R5 IoU thresholds and AP
log("[R5] IoU thresholds and AP")
THRS = np.round(np.arange(0.5, 0.951, 0.05), 2)
_PC, EV = {}, {}
def prop_conf(seq, k, t):
    key = (seq, k, t)
    if key in _PC: return _PC[key]
    sq = S[seq]; boxes = sq.c["det"][k]["boxes"]; conf = sq.c["det"][k]["conf"]
    if len(boxes) == 0:
        _PC[key] = (boxes, conf); return _PC[key]
    s = FLOW_SCALE
    x1, y1, x2, y2 = boxes[:, 0], boxes[:, 1], boxes[:, 2], boxes[:, 3]
    pts = np.stack([np.stack([x1, y1], 1), np.stack([x2, y1], 1), np.stack([x1, y2], 1),
                    np.stack([x2, y2], 1), np.stack([(x1 + x2) / 2, (y1 + y2) / 2], 1)], 1)
    p0 = (pts.reshape(-1, 2) * s).astype(np.float32).reshape(-1, 1, 2)
    p1, stt, _ = cv2.calcOpticalFlowPyrLK(sq.c["flow"][k], sq.c["flow"][t], p0, None, winSize=(21, 21), maxLevel=3,
                                          criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, 0.01))
    if p1 is None or stt is None:
        _PC[key] = (boxes.copy(), conf.copy()); return _PC[key]
    disp = ((p1 - p0).reshape(-1, 5, 2)) / s; ok = stt.reshape(-1, 5) > 0
    ob, oc = [], []
    for i, b in enumerate(boxes):
        if ok[i].sum() < 3:
            ob.append(b.copy()); oc.append(conf[i]); continue
        dx = float(np.median(disp[i, ok[i], 0])); dy = float(np.median(disp[i, ok[i], 1]))
        nb = [np.clip(b[0] + dx, 0, sq.W - 1), np.clip(b[1] + dy, 0, sq.H - 1),
              np.clip(b[2] + dx, 0, sq.W - 1), np.clip(b[3] + dy, 0, sq.H - 1)]
        if nb[2] > nb[0] and nb[3] > nb[1]:
            ob.append(nb); oc.append(conf[i])
    _PC[key] = (np.asarray(ob, np.float32).reshape(-1, 4), np.asarray(oc, np.float32))
    return _PC[key]

def frame_eval(seq, k, t):
    key = (seq, k, t)
    if key in EV: return EV[key]
    sq = S[seq]; g = sq.gt_of(t)
    if k == t: b, cf = sq.c["det"][t]["boxes"], sq.c["det"][t]["conf"]
    else: b, cf = prop_conf(seq, k, t)
    m = iou_matrix(b, g) if len(b) and len(g) else np.zeros((len(b), len(g)))
    order = np.argsort(-cf, kind="mergesort"); tps = np.zeros((len(THRS), len(b)), bool)
    if len(g):
        for ti, thr in enumerate(THRS):
            used = np.zeros(len(g), bool)
            for d in order:
                iou = np.where(used, -1.0, m[d]); j = int(np.argmax(iou))
                if iou[j] >= thr: used[j] = True; tps[ti, d] = True
    cnt = {thr: match_counts(b, g, thr) for thr in (0.5, 0.6, 0.75)}
    EV[key] = (cf, tps, len(g), cnt)
    return EV[key]

def ap_coco(scores, tp, npos):
    if npos == 0 or len(scores) == 0: return 0.0
    o = np.argsort(-scores, kind="mergesort"); tp = tp[o]
    ctp = np.cumsum(tp); cfp = np.cumsum(~tp)
    rec = ctp / npos; prec = ctp / np.maximum(ctp + cfp, 1e-9)
    prec = np.maximum.accumulate(prec[::-1])[::-1]
    idx = np.searchsorted(rec, np.linspace(0, 1, 101), side="left")
    return float(np.where(idx < len(prec), prec[np.minimum(idx, len(prec) - 1)], 0.0).mean())

def eval_full(seq, runs, lo, hi):
    run = set(runs); k = lo - 1; S_, T_, npos = [], [], 0; cnt = {0.5: [0, 0, 0], 0.6: [0, 0, 0], 0.75: [0, 0, 0]}
    for t in range(lo, hi + 1):
        if t in run: k = t
        cf, tps, ng, c = frame_eval(seq, k, t)
        S_.append(cf); T_.append(tps); npos += ng
        for thr in cnt:
            for i in range(3): cnt[thr][i] += c[thr][i]
    sc = np.concatenate(S_) if S_ else np.zeros(0); tp = np.concatenate(T_, axis=1) if T_ else np.zeros((len(THRS), 0), bool)
    aps = [ap_coco(sc, tp[i], npos) for i in range(len(THRS))]
    out = {f"f1@{thr}": prf(*cnt[thr])[2] for thr in cnt}
    out["p@0.5"], out["r@0.5"] = prf(*cnt[0.5])[:2]
    out["ap50"], out["ap75"], out["ap50_95"] = aps[0], aps[5], float(np.mean(aps))
    return out

p5 = ck("R5_metrics.csv")
if os.path.exists(p5): MET = pd.read_csv(p5)
else:
    mrows = []
    for s in SEQS:
        fd = FOLDS[s]; ft = FastTree(fd["clf"]); lo, hi = win2(s)
        mrows.append({"seq": s, "rho": 1.0, "method": "fixed", "calls": hi - lo + 1, **eval_full(s, range(lo, hi + 1), lo, hi)})
        for rho in RHOS:
            runs = ppv_budget_schedule(s, lo, hi, rho, fd["tau"], fd["cap"], ft); n = len(runs)
            for meth, rr in [("ppv", runs), ("periodic", periodic_schedule(lo, hi, n)),
                             ("framediff", framediff_schedule(s, lo, hi, n))]:
                mrows.append({"seq": s, "rho": round(rho, 4), "method": meth, "calls": len(rr), **eval_full(s, rr, lo, hi)})
        log(f"   metrics {s} | {time.time()-T_REV:.0f}s")
    MET = pd.DataFrame(mrows); MET.to_csv(p5, index=False)

# ---------------------------------------------------------------- R6 random spread
log("[R6] random baseline spread")
rr = []
for r in loso.itertuples(index=False):
    lo, hi = win2(r.seq)
    rf = np.array([eval_schedule(r.seq, random_schedule(lo, hi, int(r.calls), sd), lo, hi)[2] for sd in range(N_RANDOM)])
    rr.append({"seq": r.seq, "rho": r.rho, "calls": r.calls, "ppv_f1": r.ppv_f1, "periodic_f1": r.periodic_f1,
               "rand_mean": rf.mean(), "rand_sd": rf.std(ddof=1), "rand_min": rf.min(), "rand_max": rf.max(),
               "ppv_beats_n_of_20": int((r.ppv_f1 > rf).sum()), "periodic_beats_n_of_20": int((r.periodic_f1 > rf).sum())})
RND = pd.DataFrame(rr); RND.to_csv(ck("R6_random.csv"), index=False)

# ---------------------------------------------------------------- R7 sequence-level statistics
log("[R7] sequence-level statistics")
def seqstats(df, col, margin=0.003, label=""):
    per = df.groupby("seq")[col].mean(); x = per.values; n = len(x); m = x.mean()
    signs = np.array(list(itertools.product([1, -1], repeat=n)))
    null = (signs * x).mean(1)
    p_perm_two = float(np.mean(np.abs(null) >= abs(m) - 1e-15))
    p_perm_gt = float(np.mean(null >= m - 1e-15))
    rng = np.random.default_rng(0); grp = [df[df.seq == s][col].values for s in per.index]
    boots = np.array([np.mean(np.concatenate([grp[i] for i in rng.integers(0, n, n)])) for _ in range(10000)])
    se = x.std(ddof=1) / np.sqrt(n); tcrit90 = _st.t.ppf(.95, n - 1); tcrit95 = _st.t.ppf(.975, n - 1)
    p_tost = max(ttest_1samp(x, -margin, alternative="greater").pvalue, ttest_1samp(x, margin, alternative="less").pvalue)
    rel = (df[col] / df["fixed_f1"]).groupby(df["seq"]).mean() * 100 if "fixed_f1" in df else pd.Series(dtype=float)
    out = {"set": label, "metric": col, "n_seq": n, "seq_mean": m, "seq_sd": float(x.std(ddof=1)),
           "wins_seq": int((x > 0).sum()), "losses_seq": int((x < 0).sum()),
           "t95_lo": m - tcrit95 * se, "t95_hi": m + tcrit95 * se,
           "boot95_lo": float(np.percentile(boots, 2.5)), "boot95_hi": float(np.percentile(boots, 97.5)),
           "perm_p_two": p_perm_two, "perm_p_greater": p_perm_gt,
           "wilcoxon7_p_two": float(wilcoxon(x).pvalue) if n >= 6 and np.any(x != 0) else float("nan"),
           "tost_p_seq": float(p_tost), "smallest_equiv_margin": float(max(abs(m - tcrit90 * se), abs(m + tcrit90 * se))),
           "rel_mean_pct_of_fixed": float(rel.mean()) if len(rel) else float("nan")}
    try:
        import statsmodels.formula.api as smf
        md = smf.mixedlm(f"{col} ~ 1", df.reset_index(drop=True), groups=df.reset_index(drop=True)["seq"]).fit(reml=True)
        ci_ = md.conf_int().loc["Intercept"]
        out.update({"mixed_est": float(md.params["Intercept"]), "mixed_lo": float(ci_[0]), "mixed_hi": float(ci_[1]),
                    "mixed_p": float(md.pvalues["Intercept"])})
    except Exception as e:
        out["mixed_note"] = str(e)[:60]
    return out
st_rows = []
L2 = loso.copy()
for col in ["d_periodic", "d_framediff", "d_random"]:
    st_rows.append(seqstats(L2, col, label="MOT17"))
if "er" in globals():
    E2 = er[er.dataset.astype(str).str.startswith("MOT20")].copy(); E2["seq"] = E2["seq"].astype(str)
    for col in ["d_periodic", "d_framediff", "d_random"]:
        st_rows.append(seqstats(E2, col, label="MOT20"))
        st_rows.append(seqstats(E2[~E2.seq.str.contains("MOT20-03|MOT20-05")], col, label="MOT20 excl 03,05"))
        both = pd.concat([L2[["seq", col, "fixed_f1"]], E2[["seq", col, "fixed_f1"]]])
        st_rows.append(seqstats(both, col, label="MOT17+MOT20"))
for tag in ["gap_only", "gap+scene", "scene_only", "no_controller", "dense_gaps_1_20", "dagger_2rounds"]:
    d = pd.concat([ABL, SHIFT_VAR]); d = d[d.variant == tag]
    if len(d): st_rows.append(seqstats(d, "d_periodic", label=f"variant {tag}"))
SEQST = pd.DataFrame(st_rows); SEQST.to_csv(ck("R7_seqstats.csv"), index=False)

# ---------------------------------------------------------------- R8 MOT20 detail
if "er" in globals():
    er.to_csv(ck("R8_mot20_all.csv"), index=False)

# ---------------------------------------------------------------- R9 / R10 online timing
def lk_prop(fk, ft_, boxes, conf, W, H):
    if len(boxes) == 0: return boxes, conf
    s = FLOW_SCALE
    x1, y1, x2, y2 = boxes[:, 0], boxes[:, 1], boxes[:, 2], boxes[:, 3]
    pts = np.stack([np.stack([x1, y1], 1), np.stack([x2, y1], 1), np.stack([x1, y2], 1),
                    np.stack([x2, y2], 1), np.stack([(x1 + x2) / 2, (y1 + y2) / 2], 1)], 1)
    p0 = (pts.reshape(-1, 2) * s).astype(np.float32).reshape(-1, 1, 2)
    p1, stt, _ = cv2.calcOpticalFlowPyrLK(fk, ft_, p0, None, winSize=(21, 21), maxLevel=3,
                                          criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, 0.01))
    if p1 is None or stt is None: return boxes, conf
    disp = ((p1 - p0).reshape(-1, 5, 2)) / s; ok = stt.reshape(-1, 5) > 0
    ob, oc = [], []
    for i, b in enumerate(boxes):
        if ok[i].sum() < 3: ob.append(b); oc.append(conf[i]); continue
        dx = float(np.median(disp[i, ok[i], 0])); dy = float(np.median(disp[i, ok[i], 1]))
        nb = [min(max(b[0] + dx, 0), W - 1), min(max(b[1] + dy, 0), H - 1),
              min(max(b[2] + dx, 0), W - 1), min(max(b[3] + dy, 0), H - 1)]
        if nb[2] > nb[0] and nb[3] > nb[1]: ob.append(nb); oc.append(conf[i])
    return np.asarray(ob, np.float32).reshape(-1, 4), np.asarray(oc, np.float32)

def person_boxes(r):
    if r.boxes is None or len(r.boxes) == 0: return np.zeros((0, 4), np.float32), np.zeros(0, np.float32)
    b = r.boxes.xyxy.detach().cpu().numpy().astype(np.float32); cf = r.boxes.conf.detach().cpu().numpy().astype(np.float32)
    k = r.boxes.cls.detach().cpu().numpy().astype(np.int32) == 0
    return b[k], cf[k]

def fd_threshold(seq, lo, hi, n):
    sq = S[seq]
    def run(th):
        k, r = lo - 1, []
        for t in range(lo, hi + 1):
            if sq.scene_diff(t, k) >= th: r.append(t); k = t
        return r
    a, b = 0.0, 1.0; best, bth = run(0.0), 0.0
    for _ in range(40):
        m = (a + b) / 2; r = run(m)
        if len(r) > n: a = m
        else: b = m; best, bth = r, m
        if len(r) == n: return m
    return bth

ENERGY = None
if not FAKE:
    try:
        try: import pynvml
        except ImportError:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "nvidia-ml-py"]); import pynvml
        pynvml.nvmlInit(); _NH = pynvml.nvmlDeviceGetHandleByIndex(0)
        pynvml.nvmlDeviceGetTotalEnergyConsumption(_NH)
        ENERGY = lambda: pynvml.nvmlDeviceGetTotalEnergyConsumption(_NH) / 1000.0     # joules
        GPU_NAME = pynvml.nvmlDeviceGetName(_NH)
    except Exception as e:
        log("   NVML energy counter unavailable:", e)

def online(seq, imgs, lo, hi, method, mdl, dev, rho=None, n=None, th=None, fold_=None):
    """One causal pass over frames lo..hi; returns timing, energy, calls and online F1."""
    W, H = DATA[seq]["W"], DATA[seq]["H"]
    gpu = (dev != "cpu") and not FAKE
    def sync():
        if gpu:
            import torch; torch.cuda.synchronize()
    def detect(img):
        r = mdl([img], verbose=False, device=dev)[0]; return person_boxes(r)
    # state at lo-1 (identical for all methods, outside the clock)
    g0 = cv2.cvtColor(imgs[lo - 1], cv2.COLOR_BGR2GRAY)
    flow_k = cv2.resize(g0, None, fx=FLOW_SCALE, fy=FLOW_SCALE, interpolation=cv2.INTER_AREA)
    small_k = cv2.resize(g0, SMALL, interpolation=cv2.INTER_AREA)
    bk, ck_ = detect(imgs[lo - 1]); k = lo - 1
    per = set(periodic_schedule(lo, hi, n)) if method == "periodic" else None
    ft = FastTree(fold_["clf"]) if method == "ppv" else None
    c = 0.0; calls = 0; det = pre = feat = flow = 0.0; tp = fp = fn = 0; runs = []
    e0 = ENERGY() if ENERGY else None
    sync(); T0 = time.perf_counter()
    for t in range(lo, hi + 1):
        img = imgs[t]
        if method == "fixed":
            sync(); a = time.perf_counter(); b, cf = detect(img); sync(); det += time.perf_counter() - a
            calls += 1; runs.append(t)
        else:
            a = time.perf_counter()
            g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            flow_t = cv2.resize(g, None, fx=FLOW_SCALE, fy=FLOW_SCALE, interpolation=cv2.INTER_AREA)
            small_t = cv2.resize(g, SMALL, interpolation=cv2.INTER_AREA) if method != "periodic" else None
            pre += time.perf_counter() - a
            a = time.perf_counter()
            if method == "periodic":
                run = t in per
            elif method == "framediff":
                run = float(np.abs(small_t.astype(np.float32) - small_k.astype(np.float32)).mean() / 255.0) >= th
            else:
                c += rho; run = False
                if c >= 1.0:
                    if c >= fold_["cap"]: run = True
                    else:
                        h = cv2.calcHist([small_t], [0], None, [32], [0, 256]).ravel()
                        p = h / h.sum() if h.sum() > 0 else h; p = p[p > 0]
                        ent = float(-(p * np.log2(p)).sum()) if len(p) else 0.0
                        x = [t - k, ent, float(small_t.mean() / 255.0 - small_k.mean() / 255.0),
                             float(ck_.mean()) if len(ck_) else 0.0,
                             float(np.abs(small_t.astype(np.float32) - small_k.astype(np.float32)).mean() / 255.0)]
                        run = ft(x) >= fold_["tau"]
                    if run: c -= 1.0
            feat += time.perf_counter() - a
            if run:
                sync(); a = time.perf_counter(); b, cf = detect(img); sync(); det += time.perf_counter() - a
                calls += 1; runs.append(t); k = t; bk, ck_, flow_k, small_k = b, cf, flow_t, small_t
            else:
                a = time.perf_counter(); b, cf = lk_prop(flow_k, flow_t, bk, ck_, W, H); flow += time.perf_counter() - a
        x_, y_, z_ = match_counts(b, DATA[seq]["gt"].get(t, np.zeros((0, 4), np.float32)))
        tp += x_; fp += y_; fn += z_
    sync(); total = time.perf_counter() - T0
    e = (ENERGY() - e0) if ENERGY else float("nan")
    nfr = hi - lo + 1
    return {"seq": seq, "method": method, "rho": rho if rho else 1.0, "frames": nfr, "target": (rho or 1.0) * nfr,
            "calls": calls, "total_ms": total * 1000, "ms_per_frame": total * 1000 / nfr, "fps": nfr / total,
            "det_ms": det * 1000, "pre_ms": pre * 1000, "sched_ms": feat * 1000, "flow_ms": flow * 1000,
            "energy_J": e, "mJ_per_frame": e * 1000 / nfr if e == e else float("nan"),
            "f1_online": prf(tp, fp, fn)[2], "max_gap": int(np.diff([lo - 1] + runs).max()) if runs else nfr}

def timing_block(tag, mdl, dev, seqs, lo, hi, rhos, repeats, methods=("fixed", "ppv", "periodic", "framediff")):
    path = ck(f"timing_{tag}.csv")
    rows = pd.read_csv(path).to_dict("records") if os.path.exists(path) else []
    have = {(r["seq"], int(r["run"])) for r in rows}
    for s in seqs:
        if all((s, rr_) in have for rr_ in range(repeats)): continue
        hi_s = min(hi, DATA[s]["n"]); fd = FOLDS[s]; ft = FastTree(fd["clf"])
        plan = {}
        for rho in rhos:
            n = len(ppv_budget_schedule(s, lo, hi_s, rho, fd["tau"], fd["cap"], ft))
            plan[rho] = (n, fd_threshold(s, lo, hi_s, n))
        files = sorted(glob.glob(os.path.join(found[s], "*.jpg")))
        imgs = {f: cv2.imread(files[f - 1]) for f in range(lo - 1, hi_s + 1)}          # decode outside the clock
        if FAKE:
            for f, im in imgs.items(): FAKE_GT_LOOKUP[id(im)] = DATA[s]["gt"].get(f, np.zeros((0, 4), np.float32))
        for _ in range(5): mdl([imgs[lo]], verbose=False, device=dev)                      # warm-up
        for run in range(repeats):
            if (s, run) in have: continue
            jobs = [("fixed", None)] if "fixed" in methods else []
            jobs += [(m_, rho) for rho in rhos for m_ in methods if m_ != "fixed"]
            random.Random(1000 * run + len(s)).shuffle(jobs)                               # order effects
            for m_, rho in jobs:
                n, th = plan[rho] if rho else (None, None)
                r = online(s, imgs, lo, hi_s, m_, mdl, dev, rho=rho, n=n, th=th, fold_=fd)
                r.update({"run": run, "regime": tag, "planned_calls": n if n else hi_s - lo + 1})
                rows.append(r)
            pd.DataFrame(rows).to_csv(path, index=False)
            log(f"   timing[{tag}] {s} run {run} done | {time.time()-T_REV:.0f}s")
        del imgs
    return pd.DataFrame(rows)

import random
TIM = []
if RUN_TIMING:
    log("[R9] online timing, final 5-feature budgeted PPV-Lite (yolo11m, GPU)")
    TIM.append(timing_block("yolo11m_gpu", model, 0, [q for q in SEQS if q not in SKIP_TIMING], TIME_LO, TIME_HI, RHOS, REPEATS))
if RUN_NANO:
    log("[R10] cheap-detector regime (yolo11n, GPU)")
    nano = model if FAKE else YOLO("yolo11n.pt")
    TIM.append(timing_block("yolo11n_gpu", nano, 0, ["MOT17-02-FRCNN"], TIME_LO, TIME_HI, RHOS, REPEATS))
if RUN_CPU:
    log("[R10] CPU-only regime (yolo11m on CPU, 100 frames)")
    cpu_m = model if FAKE else YOLO("yolo11m.pt")
    TIM.append(timing_block("yolo11m_cpu", cpu_m, "cpu", ["MOT17-02-FRCNN"], TIME_LO, TIME_LO + 99,
                            [1/4, 1/10], 1, methods=("fixed", "ppv", "periodic")))
TIM = pd.concat(TIM) if TIM else pd.DataFrame()

# ---------------------------------------------------------------- figures
if len(TIM):
    g = TIM[TIM.regime == "yolo11m_gpu"].groupby(["method", "rho"]).agg(
        ms=("ms_per_frame", "mean"), f1=("f1_online", "mean")).reset_index()
    fig, ax = plt.subplots(figsize=(6.2, 4.2))
    sty = {"ppv": ("o-", "#d62728", "PPV-Lite"), "periodic": ("s--", "#1f77b4", "Periodic"),
           "framediff": ("^:", "#2ca02c", "Frame-difference"), "fixed": ("*", "black", "Fixed")}
    for m_, (mk, col, lab) in sty.items():
        d = g[g.method == m_].sort_values("ms")
        ax.plot(d.ms, d.f1, mk, color=col, label=lab, ms=9 if m_ == "fixed" else 6)
    ax.set_xlabel("End-to-end time per frame (ms)"); ax.set_ylabel("F1 (IoU 0.5), mean of 7 sequences")
    ax.legend(loc="lower right"); ax.grid(alpha=.3); fig.tight_layout()
    fig.savefig(ck("fig_runtime_f1.pdf")); fig.savefig(ck("fig_runtime_f1.png"), dpi=200)

# ---------------------------------------------------------------- summary
pd.set_option("display.width", 250); pd.set_option("display.max_columns", 40); pd.set_option("display.max_rows", 500)
log("\n=== REVISION SUMMARY ===")
log("GPU:", globals().get("GPU_NAME", "n/a"), "| energy counter:", bool(ENERGY))
log("\n[R0] calls vs target rho*T (LOSO + MOT20): by budget")
log(CR.groupby(["set", "rho"]).agg(target=("target", "mean"), calls_min=("calls", "min"), calls_max=("calls", "max"),
                                   dev_min=("dev", "min"), dev_max=("dev", "max")).round(2).to_string())
log(f"all schedules inside rho*T - C < n <= rho*T: {bool(CR.within_bound.all())} ({int(CR.within_bound.sum())}/{len(CR)})")
log("max gap vs ceil(C/rho):", GAPS.groupby("rho")[["max_gap", "bound"]].max().to_string())
log("\n[R1] label statistics"); log(LST.round(4).to_string(index=False))
def vsum(d):
    s = d.groupby("variant").agg(mean_d=("d_periodic", "mean"), wins=("d_periodic", lambda x: int((x > 1e-12).sum())),
                                 losses=("d_periodic", lambda x: int((x < -1e-12).sum())),
                                 ret=("ppv_f1", lambda x: 0), auc=("auc", "mean"), bacc=("bacc", "mean"),
                                 dev_abs=("calls", lambda x: 0), bytes=("model_bytes", "first"), lat_us=("latency_us", "first"))
    s["ret"] = d.assign(r=100 * d.ppv_f1 / d.fixed_f1).groupby("variant").r.mean()
    s["dev_abs"] = d.assign(r=(d.calls - d.target).abs()).groupby("variant").r.mean()
    s["seq_mean_d"] = d.groupby(["variant", "seq"]).d_periodic.mean().groupby("variant").mean()
    s["seq_wins"] = d.groupby(["variant", "seq"]).d_periodic.mean().groupby("variant").apply(lambda x: f"{(x>0).sum()}/{len(x)}")
    return s
log("\n[R2] feature ablation (LOSO, 42 schedules each)"); log(vsum(ABL).round(4).to_string())
log("\n[R3] classifier ablation"); log(vsum(CLS).round(4).to_string())
log("\n[R4] training vs inference states (per test sequence)"); log(SHIFT.round(3).to_string(index=False))
log("\n[R4] dense gaps and DAgger"); log(vsum(SHIFT_VAR).round(4).to_string())
log("\n[R5] metrics by method (mean over 7 sequences)")
log(MET.groupby(["method", "rho"])[["f1@0.5", "f1@0.6", "f1@0.75", "ap50", "ap75", "ap50_95"]].mean().round(4).to_string())
mp = MET[MET.method != "fixed"].pivot_table(index=["seq", "rho"], columns="method",
                                              values=["f1@0.5", "f1@0.6", "f1@0.75", "ap50", "ap50_95"])
for mtr in ["f1@0.5", "f1@0.6", "f1@0.75", "ap50", "ap50_95"]:
    d = mp[mtr]["ppv"] - mp[mtr]["periodic"]; ds_ = d.groupby(level=0).mean()
    log(f"  PPV - periodic {mtr:8s}: mean {d.mean():+.4f} | wins {int((d>1e-12).sum())}/{len(d)} | "
        f"seq-level wins {(ds_>0).sum()}/{len(ds_)} | seq means {np.round(ds_.values, 4).tolist()}")
log("\n[R6] random baseline spread"); log(RND.round(4).to_string(index=False))
log("\n[R7] sequence-level statistics"); log(SEQST.round(5).to_string(index=False))
if "er" in globals():
    log("\n[R8] MOT20 per sequence (mean over budgets)")
    log(er.groupby("seq")[["fixed_f1", "ppv_f1", "periodic_f1", "d_periodic", "d_framediff", "d_random"]].mean().round(4).to_string())
if len(TIM):
    log("\n[R9/R10] online timing (mean over sequences and runs)")
    log(TIM.groupby(["regime", "method", "rho"])[["calls", "target", "ms_per_frame", "fps", "det_ms", "pre_ms",
                                                   "sched_ms", "flow_ms", "mJ_per_frame", "f1_online", "max_gap"]]
        .mean().round(3).to_string())
    fx = TIM[TIM.method == "fixed"].groupby(["regime", "seq", "run"]).total_ms.first().rename("fixed_ms")
    T2 = TIM.join(fx, on=["regime", "seq", "run"]); T2["saving_pct"] = 100 * (1 - T2.total_ms / T2.fixed_ms)
    log("\nsaving vs fixed (%), mean and sd over runs, per sequence, yolo11m GPU")
    log(T2[(T2.regime == "yolo11m_gpu") & (T2.method != "fixed")].groupby(["method", "rho", "seq"]).saving_pct
        .agg(["mean", "std"]).round(1).unstack("seq").to_string())
    log("\nsaving vs fixed (%), all regimes")
    log(T2[T2.method != "fixed"].groupby(["regime", "method", "rho"]).saving_pct.agg(["mean", "std"]).round(1).to_string())
    T2.to_csv(ck("timing_all.csv"), index=False)
shutil.make_archive(os.path.join(OUT, "revision"), "zip", REV)
log(f"\nSaved {os.path.join(OUT, 'revision.zip')} | total {time.time()-T_REV:.0f}s")



# =====================================================================
# REVISION ROUND 2  (second reviewer report)
#   S0  software / hardware environment                          (17)
#   S1  equivalence-margin sensitivity                           (4)
#   S2  gap-only vs PPV-Lite vs periodic vs frame difference:
#       F1, retention, call positions, gap distribution          (1)
#   S3  causal frame-difference baselines + tracking-uncertainty
#       trigger (contemporary principle, ALBIREO-style)          (6, 7)
#   S4  dynamic streams: abrupt jumps, speed bursts, mixed;
#       trees trained on normal video and on dynamic streams     (2, 10)
#   S5  YOLO11n: full leave-one-sequence-out scheduler study     (5)
#   S6  timing: gap-only and thumbnail reuse                     (13, 14)
#   S7  UA-DETRAC traffic (only if added as Kaggle input)        (8)
# Everything checkpoints to /kaggle/working/ppv_v2/revision2.
# At the end: download /kaggle/working/ppv_v2/revision2.zip and upload it.
# =====================================================================
import platform
REV2 = os.path.join(OUT, "revision2"); os.makedirs(REV2, exist_ok=True)
def ck2(name): return os.path.join(REV2, name)
T2 = time.time()
RUN_UNC = True                 # tracking-uncertainty trigger (slowest part, about 10 min)
RUN_TIMING2 = True
SCEN = ["jump", "burst", "mixed"]
CAPS_DYN = [1.5, 2.0, 3.0, 4.0]

# ---------------------------------------------------------------- S0 environment
env = {"python": platform.python_version(), "os": platform.platform(), "numpy": np.__version__,
       "opencv": cv2.__version__, "pandas": pd.__version__}
try:
    import sklearn; env["scikit-learn"] = sklearn.__version__
except Exception: pass
try:
    import torch; env["torch"] = torch.__version__; env["cuda"] = torch.version.cuda
    env["cudnn"] = str(torch.backends.cudnn.version()); env["gpu"] = torch.cuda.get_device_name(0) if torch.cuda.is_available() else "none"
except Exception: pass
try:
    import ultralytics; env["ultralytics"] = ultralytics.__version__
except Exception: pass
try:
    env["driver"] = subprocess.run(["nvidia-smi", "--query-gpu=driver_version", "--format=csv,noheader"],
                                   capture_output=True, text=True).stdout.strip()
except Exception: pass
try:
    cpu = subprocess.run(["lscpu"], capture_output=True, text=True).stdout
    env["cpu"] = " | ".join(l.split(":", 1)[1].strip() for l in cpu.splitlines()
                            if l.startswith(("Model name", "CPU(s):", "Thread(s) per core")))
except Exception: pass
try:
    env["ram_GB"] = round(os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 2**30, 1)
except Exception: pass
env["yolo_weights"] = "yolo11m.pt / yolo11n.pt (Ultralytics release assets), imgsz 640, conf 0.25, iou 0.7, classes person only (post-filter)"
json.dump(env, open(ck2("S0_environment.json"), "w"), indent=1)

# ---------------------------------------------------------------- S1 equivalence margins
def tost_rows(df, col, label):
    x = df.groupby("seq")[col].mean().values; out = []
    se = x.std(ddof=1) / np.sqrt(len(x))
    for m in [0.001, 0.002, 0.003, 0.005]:
        p = max(ttest_1samp(x, -m, alternative="greater").pvalue, ttest_1samp(x, m, alternative="less").pvalue)
        out.append({"set": label, "metric": col, "margin": m, "n_seq": len(x), "mean": x.mean(),
                    "ci90_lo": x.mean() - _st.t.ppf(.95, len(x) - 1) * se, "ci90_hi": x.mean() + _st.t.ppf(.95, len(x) - 1) * se,
                    "tost_p": p, "equivalent_at_5pct": bool(p < 0.05),
                    "nhst_p_two": float(ttest_1samp(x, 0).pvalue)})
    return out
eq = tost_rows(loso, "d_periodic", "MOT17")
if "er" in globals():
    E2b = er[er.dataset.astype(str).str.startswith("MOT20")]
    eq += tost_rows(E2b, "d_periodic", "MOT20")
    eq += tost_rows(pd.concat([loso[["seq", "d_periodic"]], E2b[["seq", "d_periodic"]]]), "d_periodic", "MOT17+MOT20")
EQ = pd.DataFrame(eq); EQ.to_csv(ck2("S1_margins.csv"), index=False)

# ---------------------------------------------------------------- helpers
def labels_key(key, gaps=LABEL_GAPS, lo=2, hi=None):
    p = ck2(f"labels_{key.replace('/', '_')}.csv")
    if os.path.exists(p): return pd.read_csv(p)
    sq, rows = S[key], []; hi = hi or DATA[key]["n"]
    for t in range(max(2, lo), hi + 1):
        _, _, fr = prf(*sq.det_counts(t))
        for g in gaps:
            k = t - g
            if k < 1: continue
            _, _, fp_ = prf(*sq.prop_counts(k, t))
            rows.append([key, t, *feats5(sq, t, k), int(fr > fp_), fr - fp_])
    df = pd.DataFrame(rows, columns=["seq", "frame"] + FEATS5 + ["beneficial", "delta"])
    df.to_csv(p, index=False); return df

def tune2(train, tabs, fb, taus, caps):
    best = None
    for tau in taus:
        for cap in caps:
            gains = []
            for s in train:
                lo, hi = win2(s)
                for rho in RHOS:
                    runs = sched_tab(s, lo, hi, rho, tau, cap, tabs[s], fb)
                    gains.append(eval_schedule(s, runs, lo, hi)[2] - per_f1(s, lo, hi, len(runs)))
            g = float(np.mean(gains))
            if best is None or g > best[2]: best = (tau, cap, g)
    return best

def train_sched(train_df, tune_keys, all_keys, cols, caps=CAP_GRID):
    """Fit a depth-3 tree on train_df[cols], tune (tau, C) on tune_keys, return a scheduler bundle."""
    m = fit_model("dt3", train_df, cols); sc = scorer("dt3", m); fb = make_fb(sc, cols)
    tabs = {k: table(k, sc, cols) for k in set(all_keys) | set(tune_keys)}
    tau, cap, g = tune2(tune_keys, tabs, fb, TAU_GRID, caps)
    return {"clf": m, "sc": sc, "fb": fb, "tabs": tabs, "tau": tau, "cap": cap, "cols": cols}

def run_bundle(key, b, rho):
    lo, hi = win2(key)
    if key not in b["tabs"]: b["tabs"][key] = table(key, b["sc"], b["cols"])
    return sched_tab(key, lo, hi, rho, b["tau"], b["cap"], b["tabs"][key], b["fb"])

GAPC = [FIDX["gap"]]; ALLC = list(range(5))

# ---- causal frame difference
def fd_rate_threshold(keys, rho):
    """Threshold that gives mean call rate rho on the given (training) sequences; causal at test time."""
    def rate(th):
        r = []
        for s in keys:
            lo, hi = win2(s); sq = S[s]; k, n = lo - 1, 0
            for t in range(lo, hi + 1):
                if sq.scene_diff(t, k) >= th: n += 1; k = t
            r.append(n / (hi - lo + 1))
        return np.mean(r)
    a, b = 0.0, 1.0
    for _ in range(30):
        m = (a + b) / 2
        if rate(m) > rho: a = m
        else: b = m
    return b
def fd_fixed(key, th):
    lo, hi = win2(key); sq = S[key]; k, r = lo - 1, []
    for t in range(lo, hi + 1):
        if sq.scene_diff(t, k) >= th: r.append(t); k = t
    return r
def fd_adaptive(key, th0, rho, eta=0.002):
    """Causal rate-tracking threshold: th <- th + eta * (run - rho) after every frame."""
    lo, hi = win2(key); sq = S[key]; k, r, th = lo - 1, [], th0
    for t in range(lo, hi + 1):
        run = sq.scene_diff(t, k) >= th
        if run: r.append(t); k = t
        th = max(0.0, th + eta * (float(run) - rho))
    return r
def fd_bucket(key, rho, th, cap):
    lo, hi = win2(key); sq = S[key]; k, c, r = lo - 1, 0.0, []
    for t in range(lo, hi + 1):
        c += rho
        if c >= 1.0 and (c >= cap or sq.scene_diff(t, k) >= th):
            r.append(t); k = t; c -= 1.0
    return r
def tune_fd_bucket(train):
    vals = np.concatenate([[S[s].scene_diff(t, t - g) for t in range(101, win2(s)[1] + 1, 7) for g in (2, 4, 8)] for s in train])
    best = None
    for th in np.quantile(vals, [0.3, 0.5, 0.7, 0.8, 0.9, 0.95]):
        for cap in CAP_GRID:
            gains = []
            for s in train:
                lo, hi = win2(s)
                for rho in RHOS:
                    rr = fd_bucket(s, rho, th, cap)
                    gains.append(eval_schedule(s, rr, lo, hi)[2] - per_f1(s, lo, hi, len(rr)))
            g = np.mean(gains)
            if best is None or g > best[2]: best = (float(th), cap, g)
    return best

# ---- tracking-uncertainty trigger (ALBIREO-style principle; our reimplementation)
_UNC = {}
def unc(key, k, t):
    kk = (key, k, t)
    if kk in _UNC: return _UNC[kk]
    c = DATA[key]; boxes = c["det"][k]["boxes"]
    if len(boxes) == 0: _UNC[kk] = 1.0; return 1.0
    p0 = (np.stack([(boxes[:, 0] + boxes[:, 2]) / 2, (boxes[:, 1] + boxes[:, 3]) / 2], 1) * FLOW_SCALE).astype(np.float32).reshape(-1, 1, 2)
    p1, st_, err = cv2.calcOpticalFlowPyrLK(c["flow"][k], c["flow"][t], p0, None, winSize=(21, 21), maxLevel=3,
                                           criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, 0.01))
    if p1 is None: _UNC[kk] = 1.0; return 1.0
    ok = st_.ravel() > 0; e = np.minimum(err.ravel() / 20.0, 1.0)
    u = float(np.mean(np.where(ok, e, 1.0)))
    _UNC[kk] = u; return u
def unc_schedule(key, n):
    lo, hi = win2(key)
    def run(th):
        k, r = lo - 1, []
        for t in range(lo, hi + 1):
            if unc(key, k, t) >= th: r.append(t); k = t
        return r
    a, b = 0.0, 1.0; best = run(0.0)
    for _ in range(22):
        m = (a + b) / 2; r = run(m)
        if len(r) > n: a = m
        else: b = m; best = r
        if len(r) == n: return r
    return best

def gap_stats(runs, lo, hi, n):
    g = np.diff([lo - 1] + list(runs)) if len(runs) else np.array([hi - lo + 1])
    grid = np.array(periodic_schedule(lo, hi, n)) if n else np.array([lo])
    off = np.array([np.abs(grid - r).min() for r in runs]) if len(runs) else np.array([0])
    return {"gap_mean": g.mean(), "gap_sd": g.std(), "gap_cv": g.std() / max(g.mean(), 1e-9), "gap_min": int(g.min()),
            "gap_max": int(g.max()), "offset_from_grid": off.mean()}

# ---------------------------------------------------------------- S2 + S3 on normal MOT17
log("\n[S2/S3] gap-only, causal frame difference, tracking-uncertainty trigger (MOT17 LOSO)")
GAPB = {}
p2 = ck2("S2_normal.csv")
if os.path.exists(p2): N2 = pd.read_csv(p2)
else:
    rows, sched_dump = [], {}
    for s in SEQS:
        train = [x for x in SEQS if x != s]
        GAPB[s] = train_sched(pd.concat([LAB[x] for x in train]), train, SEQS, GAPC)
        fd = FOLDS[s]; ft = FastTree(fd["clf"]); lo, hi = win2(s); T = hi - lo + 1
        fixed = eval_schedule(s, range(lo, hi + 1), lo, hi)[2]
        fdb = tune_fd_bucket(train)
        for rho in RHOS:
            ppv = ppv_budget_schedule(s, lo, hi, rho, fd["tau"], fd["cap"], ft); n = len(ppv)
            th_tr = fd_rate_threshold(train, rho)
            meths = {"ppv": ppv, "gap_only": run_bundle(s, GAPB[s], rho), "periodic": periodic_schedule(lo, hi, n),
                     "fd_bisect": framediff_schedule(s, lo, hi, n), "fd_train_thr": fd_fixed(s, th_tr),
                     "fd_adaptive": fd_adaptive(s, th_tr, rho), "fd_bucket": fd_bucket(s, rho, fdb[0], fdb[1])}
            if RUN_UNC: meths["unc_bisect"] = unc_schedule(s, n)
            for m_, rr in meths.items():
                f = eval_schedule(s, rr, lo, hi)[2]
                rows.append({"seq": s, "rho": round(rho, 4), "method": m_, "calls": len(rr), "target": rho * T,
                             "f1": f, "fixed_f1": fixed, "periodic_same_calls": per_f1(s, lo, hi, len(rr)),
                             **gap_stats(rr, lo, hi, len(rr))})
                sched_dump[f"{s}|{round(rho,4)}|{m_}"] = [int(x) for x in rr]
        log(f"   {s} | {time.time()-T2:.0f}s")
    N2 = pd.DataFrame(rows); N2["d_periodic"] = N2.f1 - N2.periodic_same_calls; N2["retention"] = 100 * N2.f1 / N2.fixed_f1
    N2.to_csv(p2, index=False); json.dump(sched_dump, open(ck2("S2_schedules.json"), "w"))
if not GAPB:
    for s in SEQS:
        train = [x for x in SEQS if x != s]
        GAPB[s] = train_sched(pd.concat([LAB[x] for x in train]), train, SEQS, GAPC)

# ---------------------------------------------------------------- S4 dynamic streams
log("\n[S4] dynamic streams")
def make_stream(s, kind, seed, total=600):
    rng = np.random.default_rng(seed); n = DATA[s]["n"]; fr = []; f = 1
    wrap = lambda x: ((x - 1) % n) + 1
    while len(fr) < total:
        mode = kind if kind != "mixed" else rng.choice(["normal", "jump", "fast"])
        if kind == "burst": mode = "fast" if rng.random() < 0.4 else "normal"
        if mode == "jump":
            seg = int(rng.integers(25, 76)); fr += [wrap(f + i) for i in range(seg)]; f = wrap(f + seg + int(rng.integers(30, 151)))
        elif mode == "fast":
            seg = int(rng.integers(15, 31)); st = int(rng.integers(3, 6)); fr += [wrap(f + i * st) for i in range(seg)]; f = wrap(f + seg * st)
        else:
            seg = int(rng.integers(30, 81)); fr += [wrap(f + i) for i in range(seg)]; f = wrap(f + seg)
    fr = fr[:total]
    key = f"DYN_{kind}_{s}"; c0 = DATA[s]
    c = {"seq": key, "n": total, "W": c0["W"], "H": c0["H"], "complete": True, "src": fr,
         "det": {i + 1: c0["det"][f_] for i, f_ in enumerate(fr)},
         "small": {i + 1: c0["small"][f_] for i, f_ in enumerate(fr)},
         "flow": {i + 1: c0["flow"][f_] for i, f_ in enumerate(fr)},
         "gt": {i + 1: c0["gt"][f_] for i, f_ in enumerate(fr) if f_ in c0["gt"]}}
    DATA[key] = c; S[key] = Seq(c); return key
DYN = {kind: {s: make_stream(s, kind, 1000 + 17 * i + 101 * j) for i, s in enumerate(SEQS)} for j, kind in enumerate(SCEN)}
DLAB = {}
for kind in SCEN:
    for s in SEQS:
        DLAB[DYN[kind][s]] = labels_key(DYN[kind][s])
    log(f"   labels {kind} | {time.time()-T2:.0f}s")

p4 = ck2("S4_dynamic.csv")
if os.path.exists(p4): D4 = pd.read_csv(p4)
else:
    rows, sched_dump = [], {}
    for kind in SCEN:
        for s in SEQS:
            key = DYN[kind][s]; train = [x for x in SEQS if x != s]
            dtrain = [DYN[kind][x] for x in train]
            mix = pd.concat([LAB[x] for x in train] + [DLAB[x] for x in dtrain])
            b_ppv_dyn = train_sched(mix, dtrain, [key], ALLC, CAPS_DYN)
            b_gap_dyn = train_sched(mix, dtrain, [key], GAPC, CAPS_DYN)
            fd = FOLDS[s]; ft = FastTree(fd["clf"]); lo, hi = win2(key); T = hi - lo + 1
            fixed = eval_schedule(key, range(lo, hi + 1), lo, hi)[2]
            for rho in RHOS:
                ppv = ppv_budget_schedule(key, lo, hi, rho, fd["tau"], fd["cap"], ft); n = len(ppv)
                th_tr = fd_rate_threshold(dtrain, rho)
                meths = {"ppv": ppv, "gap_only": run_bundle(key, GAPB[s], rho),
                         "ppv_dyn": run_bundle(key, b_ppv_dyn, rho), "gap_dyn": run_bundle(key, b_gap_dyn, rho),
                         "periodic": periodic_schedule(lo, hi, n), "fd_bisect": framediff_schedule(key, lo, hi, n),
                         "fd_train_thr": fd_fixed(key, th_tr), "fd_adaptive": fd_adaptive(key, th_tr, rho)}
                if RUN_UNC and kind != "burst": meths["unc_bisect"] = unc_schedule(key, n)
                rf = [eval_schedule(key, random_schedule(lo, hi, n, sd), lo, hi)[2] for sd in range(N_RANDOM)]
                for m_, rr in meths.items():
                    rows.append({"scenario": kind, "seq": s, "rho": round(rho, 4), "method": m_, "calls": len(rr),
                                 "target": rho * T, "f1": eval_schedule(key, rr, lo, hi)[2], "fixed_f1": fixed,
                                 "periodic_same_calls": per_f1(key, lo, hi, len(rr)), "random_mean": float(np.mean(rf)),
                                 "cap_dyn": b_ppv_dyn["cap"] if m_ == "ppv_dyn" else (b_gap_dyn["cap"] if m_ == "gap_dyn" else np.nan),
                                 **gap_stats(rr, lo, hi, len(rr))})
                    sched_dump[f"{kind}|{s}|{round(rho,4)}|{m_}"] = [int(x) for x in rr]
            log(f"   {kind} {s} | {time.time()-T2:.0f}s")
    D4 = pd.DataFrame(rows); D4["d_periodic"] = D4.f1 - D4.periodic_same_calls; D4["retention"] = 100 * D4.f1 / D4.fixed_f1
    D4.to_csv(p4, index=False); json.dump(sched_dump, open(ck2("S4_schedules.json"), "w"))
    json.dump({k: [int(x) for x in DATA[v]["src"]] for kind in SCEN for k, v in [(f"{kind}|{s}", DYN[kind][s]) for s in SEQS]},
              open(ck2("S4_stream_frames.json"), "w"))

def seq_summary(df, label):
    out = []
    for m_ in df.method.unique():
        d = df[df.method == m_]
        x = d.groupby("seq").d_periodic.mean().values
        signs = np.array(list(itertools.product([1, -1], repeat=len(x)))); null = (signs * x).mean(1)
        out.append({"set": label, "method": m_, "mean_d_periodic": x.mean(), "seq_wins": int((x > 0).sum()),
                    "seq_losses": int((x < 0).sum()), "perm_p_two": float(np.mean(np.abs(null) >= abs(x.mean()) - 1e-15)),
                    "sched_wins": int((d.d_periodic > 1e-12).sum()), "sched_losses": int((d.d_periodic < -1e-12).sum()),
                    "retention": d.retention.mean(), "f1": d.f1.mean(), "call_dev": (d.calls - d.target).abs().mean(),
                    "gap_cv": d.gap_cv.mean(), "gap_max": d.gap_max.mean(), "offset_from_grid": d.offset_from_grid.mean()})
    return out
SUMM = seq_summary(N2, "MOT17 normal")
for kind in SCEN: SUMM += seq_summary(D4[D4.scenario == kind], f"dynamic {kind}")
SUMM = pd.DataFrame(SUMM); SUMM.to_csv(ck2("S2_S4_summary.csv"), index=False)
# head-to-head: content vs gap, same training data and same controller
h2h = []
for kind in SCEN:
    d = D4[D4.scenario == kind].pivot_table(index=["seq", "rho"], columns="method", values="f1")
    for a, b in [("ppv_dyn", "gap_dyn"), ("ppv", "gap_only")]:
        x = (d[a] - d[b]).groupby(level=0).mean().values
        signs = np.array(list(itertools.product([1, -1], repeat=len(x)))); null = (signs * x).mean(1)
        h2h.append({"scenario": kind, "pair": f"{a} - {b}", "mean": x.mean(), "seq_wins": int((x > 0).sum()),
                    "perm_p_two": float(np.mean(np.abs(null) >= abs(x.mean()) - 1e-15))})
x = (N2.pivot_table(index=["seq", "rho"], columns="method", values="f1").pipe(lambda d: d["ppv"] - d["gap_only"])).groupby(level=0).mean().values
h2h.append({"scenario": "normal", "pair": "ppv - gap_only", "mean": x.mean(), "seq_wins": int((x > 0).sum()), "perm_p_two": float("nan")})
H2H = pd.DataFrame(h2h); H2H.to_csv(ck2("S4_head2head.csv"), index=False)

# ---------------------------------------------------------------- S5 YOLO11n full study
log("\n[S5] YOLO11n leave-one-sequence-out study")
nano_m = model if FAKE else (nano if "nano" in globals() else YOLO("yolo11n.pt"))
NK = {}
for s in SEQS:
    key = f"N_{s}"; p = ck2(f"nano_det_{s}.pkl")
    if os.path.exists(p):
        det = pickle.load(open(p, "rb"))
    else:
        files = sorted(glob.glob(os.path.join(found[s], "*.jpg")))[:MAX_FRAMES]; det = {}; batch, ids = [], []
        for i, fp in enumerate(files, start=1):
            img = cv2.imread(fp)
            if FAKE: FAKE_GT_LOOKUP[id(img)] = DATA[s]["gt"].get(i, np.zeros((0, 4), np.float32))
            batch.append(img); ids.append(i)
            if len(batch) == 16 or i == len(files):
                for fid, r in zip(ids, nano_m(batch, verbose=False, device=0)):
                    b, cf = person_boxes(r); det[fid] = {"boxes": b, "conf": cf}
                batch, ids = [], []
        pickle.dump(det, open(p, "wb"))
    c = dict(DATA[s]); c["det"] = det; c["seq"] = key; DATA[key] = c; S[key] = Seq(c); NK[s] = key
log(f"   nano detections | {time.time()-T2:.0f}s")
NLAB = {NK[s]: labels_key(NK[s]) for s in SEQS}
p5 = ck2("S5_nano.csv")
if os.path.exists(p5): N5 = pd.read_csv(p5)
else:
    rows = []
    keys = [NK[s] for s in SEQS]
    for s in SEQS:
        key = NK[s]; train = [NK[x] for x in SEQS if x != s]
        df = pd.concat([NLAB[k] for k in train])
        b5 = train_sched(df, train, keys, ALLC); bg = train_sched(df, train, keys, GAPC)
        lo, hi = win2(key); fixed = eval_schedule(key, range(lo, hi + 1), lo, hi)[2]
        for rho in RHOS:
            ppv = run_bundle(key, b5, rho); n = len(ppv)
            rf = [eval_schedule(key, random_schedule(lo, hi, n, sd), lo, hi)[2] for sd in range(N_RANDOM)]
            for m_, rr in {"ppv": ppv, "gap_only": run_bundle(key, bg, rho), "periodic": periodic_schedule(lo, hi, n),
                           "fd_bisect": framediff_schedule(key, lo, hi, n)}.items():
                rows.append({"seq": s, "rho": round(rho, 4), "method": m_, "calls": len(rr), "target": rho * (hi - lo + 1),
                             "f1": eval_schedule(key, rr, lo, hi)[2], "fixed_f1": fixed,
                             "periodic_same_calls": per_f1(key, lo, hi, len(rr)), "random_mean": float(np.mean(rf)),
                             "tau": b5["tau"], "cap": b5["cap"], **gap_stats(rr, lo, hi, len(rr))})
        log(f"   nano fold {s} | {time.time()-T2:.0f}s")
    N5 = pd.DataFrame(rows); N5["d_periodic"] = N5.f1 - N5.periodic_same_calls; N5["retention"] = 100 * N5.f1 / N5.fixed_f1
    N5.to_csv(p5, index=False)
NSUM = pd.DataFrame(seq_summary(N5, "YOLO11n"))
NSUM_R = pd.DataFrame(seq_summary(N5.assign(periodic_same_calls=N5.random_mean, d_periodic=N5.f1 - N5.random_mean), "YOLO11n vs random"))

# ---------------------------------------------------------------- S6 timing: gap-only and thumbnail reuse
def online2(seq, imgs, lo, hi, method, mdl, dev, rho, n, fold_, gapb):
    W, H = DATA[seq]["W"], DATA[seq]["H"]; gpu = (dev != "cpu") and not FAKE
    def sync():
        if gpu:
            import torch; torch.cuda.synchronize()
    def detect(img): return person_boxes(mdl([img], verbose=False, device=dev)[0])
    g0 = cv2.cvtColor(imgs[lo - 1], cv2.COLOR_BGR2GRAY)
    flow_k = cv2.resize(g0, None, fx=FLOW_SCALE, fy=FLOW_SCALE, interpolation=cv2.INTER_AREA)
    small_k = cv2.resize(g0, SMALL, interpolation=cv2.INTER_AREA) if method == "ppv_full" else cv2.resize(flow_k, SMALL, interpolation=cv2.INTER_AREA)
    bk, ck_ = detect(imgs[lo - 1]); k = lo - 1
    per = set(periodic_schedule(lo, hi, n)) if method == "periodic" else None
    ft = FastTree(fold_["clf"]) if method.startswith("ppv") else None
    gt_ = FastTree(gapb["clf"]) if method == "gap_only" else None
    c = 0.0; calls = 0; det = pre = feat = flow = 0.0; tp = fp = fn = 0; runs = []
    e0 = ENERGY() if ENERGY else None
    sync(); T0 = time.perf_counter()
    for t in range(lo, hi + 1):
        img = imgs[t]
        if method == "fixed":
            sync(); a = time.perf_counter(); b, cf = detect(img); sync(); det += time.perf_counter() - a; calls += 1; runs.append(t)
        else:
            a = time.perf_counter()
            g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            flow_t = cv2.resize(g, None, fx=FLOW_SCALE, fy=FLOW_SCALE, interpolation=cv2.INTER_AREA)
            small_t = None
            if method == "ppv_full": small_t = cv2.resize(g, SMALL, interpolation=cv2.INTER_AREA)
            pre += time.perf_counter() - a
            a = time.perf_counter(); run = False
            if method == "periodic": run = t in per
            else:
                c += rho
                if c >= 1.0:
                    cap = fold_["cap"] if method.startswith("ppv") else gapb["cap"]
                    tau = fold_["tau"] if method.startswith("ppv") else gapb["tau"]
                    if c >= cap: run = True
                    elif method == "gap_only": run = gt_([t - k]) >= tau
                    else:
                        if small_t is None: small_t = cv2.resize(flow_t, SMALL, interpolation=cv2.INTER_AREA)
                        h = cv2.calcHist([small_t], [0], None, [32], [0, 256]).ravel()
                        p = h / h.sum() if h.sum() > 0 else h; p = p[p > 0]
                        x = [t - k, float(-(p * np.log2(p)).sum()) if len(p) else 0.0,
                             float(small_t.mean() / 255.0 - small_k.mean() / 255.0), float(ck_.mean()) if len(ck_) else 0.0,
                             float(np.abs(small_t.astype(np.float32) - small_k.astype(np.float32)).mean() / 255.0)]
                        run = ft(x) >= tau
                    if run: c -= 1.0
            feat += time.perf_counter() - a
            if run:
                if method == "ppv_reuse" and small_t is None: small_t = cv2.resize(flow_t, SMALL, interpolation=cv2.INTER_AREA)
                sync(); a = time.perf_counter(); b, cf = detect(img); sync(); det += time.perf_counter() - a
                calls += 1; runs.append(t); k = t; bk, ck_, flow_k = b, cf, flow_t
                if small_t is not None: small_k = small_t
            else:
                a = time.perf_counter(); b, cf = lk_prop(flow_k, flow_t, bk, ck_, W, H); flow += time.perf_counter() - a
        x_, y_, z_ = match_counts(b, DATA[seq]["gt"].get(t, np.zeros((0, 4), np.float32))); tp += x_; fp += y_; fn += z_
    sync(); total = time.perf_counter() - T0
    e = (ENERGY() - e0) if ENERGY else float("nan"); nfr = hi - lo + 1
    return {"seq": seq, "method": method, "rho": rho if rho else 1.0, "frames": nfr, "calls": calls,
            "ms_per_frame": total * 1000 / nfr, "fps": nfr / total, "det_ms": det * 1000 / nfr, "pre_ms": pre * 1000 / nfr,
            "sched_ms": feat * 1000 / nfr, "flow_ms": flow * 1000 / nfr, "mJ_per_frame": e * 1000 / nfr if e == e else float("nan"),
            "f1_online": prf(tp, fp, fn)[2]}

TIM2 = pd.DataFrame()
if RUN_TIMING2:
    log("\n[S6] timing: gap-only and thumbnail reuse")
    p6 = ck2("S6_timing.csv")
    rows6 = pd.read_csv(p6).to_dict("records") if os.path.exists(p6) else []
    have = {(r["seq"], int(r["run"])) for r in rows6}
    for s in SEQS:
        if all((s, r) in have for r in range(REPEATS)): continue
        hi_s = min(TIME_HI, DATA[s]["n"]); fd = FOLDS[s]; ftr = FastTree(fd["clf"])
        files = sorted(glob.glob(os.path.join(found[s], "*.jpg")))
        imgs = {f: cv2.imread(files[f - 1]) for f in range(TIME_LO - 1, hi_s + 1)}
        if FAKE:
            for f, im in imgs.items(): FAKE_GT_LOOKUP[id(im)] = DATA[s]["gt"].get(f, np.zeros((0, 4), np.float32))
        for _ in range(5): model([imgs[TIME_LO]], verbose=False, device=0)
        for run in range(REPEATS):
            if (s, run) in have: continue
            jobs = [("fixed", None)] + [(m_, rho) for rho in [1/4, 1/10] for m_ in ["periodic", "gap_only", "ppv_full", "ppv_reuse"]]
            random.Random(7 * run + len(s)).shuffle(jobs)
            for m_, rho in jobs:
                n = len(ppv_budget_schedule(s, TIME_LO, hi_s, rho, fd["tau"], fd["cap"], ftr)) if rho else None
                r = online2(s, imgs, TIME_LO, hi_s, m_, model, 0, rho, n, fd, GAPB[s]); r["run"] = run; rows6.append(r)
            pd.DataFrame(rows6).to_csv(p6, index=False)
            log(f"   timing2 {s} run {run} | {time.time()-T2:.0f}s")
        del imgs
    TIM2 = pd.DataFrame(rows6)
    fx = TIM2[TIM2.method == "fixed"].groupby(["seq", "run"]).ms_per_frame.first().rename("fixed_ms")
    TIM2 = TIM2.join(fx, on=["seq", "run"]); TIM2["saving_pct"] = 100 * (1 - TIM2.ms_per_frame / TIM2.fixed_ms)
    TIM2.to_csv(ck2("S6_timing_all.csv"), index=False)

# ---------------------------------------------------------------- summary
pd.set_option("display.width", 250); pd.set_option("display.max_columns", 40); pd.set_option("display.max_rows", 600)
log("\n=== REVISION 2 SUMMARY ===")
log("[S0] environment:", json.dumps(env, indent=1))
log("\n[S1] equivalence margins"); log(EQ.round(5).to_string(index=False))
log("\n[S2/S3/S4] methods against periodic placement with the same number of calls (sequence = unit)")
log(SUMM.round(4).to_string(index=False))
log("\n[S4] head-to-head: content vs gap only (same training data, same controller)"); log(H2H.round(5).to_string(index=False))
log("\n[S4] per scenario, method and budget (mean over sequences)")
log(D4.groupby(["scenario", "method", "rho"])[["calls", "f1", "d_periodic", "retention", "gap_cv", "gap_max", "offset_from_grid"]].mean().round(4).to_string())
log("\n[S4] tuned cap of dynamic-trained schedulers"); log(D4.groupby(["scenario", "method"]).cap_dyn.agg(lambda x: sorted(set(x.dropna()))).to_string())
log("\n[S2] normal MOT17 per budget"); log(N2.groupby(["method", "rho"])[["calls", "f1", "d_periodic", "retention", "gap_cv", "gap_max", "offset_from_grid"]].mean().round(4).to_string())
log("\n[S5] YOLO11n LOSO"); log(NSUM.round(4).to_string(index=False)); log(NSUM_R[NSUM_R.method == "ppv"].round(4).to_string(index=False))
log(N5.groupby(["method", "rho"])[["calls", "f1", "d_periodic", "retention"]].mean().round(4).to_string())
if len(TIM2):
    log("\n[S6] timing (mean over 7 sequences x runs)")
    log(TIM2.groupby(["method", "rho"])[["calls", "ms_per_frame", "fps", "det_ms", "pre_ms", "sched_ms", "flow_ms", "mJ_per_frame",
                                         "f1_online", "saving_pct"]].agg("mean").round(3).to_string())
    log(TIM2.groupby(["method", "rho"]).saving_pct.std().round(2).to_string())
if "er" in globals() and (er.dataset.astype(str) == "UA-DETRAC").any():
    U = er[er.dataset.astype(str) == "UA-DETRAC"]
    log("\n[S7] UA-DETRAC"); log(U.groupby("seq")[["fixed_f1", "ppv_f1", "periodic_f1", "d_periodic", "d_framediff", "d_random"]].mean().round(4).to_string())
    for col in ["d_periodic", "d_framediff", "d_random"]: log(seqstats(U.copy(), col, label="UA-DETRAC"))
else:
    log("\n[S7] UA-DETRAC not found (add it as a Kaggle input to include traffic video)")
shutil.make_archive(os.path.join(OUT, "revision2"), "zip", REV2)
log(f"\nSaved {os.path.join(OUT, 'revision2.zip')} | total {time.time()-T2:.0f}s")
