# =====================================================================
# DOWNLOAD MOT20 (official MOTChallenge site). Needs Internet ON.
# Downloads about 5 GB, then extracts only the 4 TRAIN sequences,
# first 600 frames each, plus their ground truth (about 1 GB on disk).
# Takes roughly 5 to 15 minutes. Run once; it skips work already done.
# =====================================================================
import os, zipfile, urllib.request, shutil, time

URL = "https://motchallenge.net/data/MOT20.zip"
ZIP = "/kaggle/tmp_mot20.zip"
DEST = "/kaggle/ext_data"
KEEP_FRAMES = 600
os.makedirs(DEST, exist_ok=True)

done = [d for d in os.listdir(DEST) if d.startswith("MOT20-")] if os.path.isdir(DEST) else []
if len(done) >= 4:
    print("MOT20 already extracted:", sorted(done))
else:
    if not os.path.exists(ZIP):
        t0 = time.time(); print("Downloading", URL)
        def hook(b, bs, total):
            if b % 2000 == 0 and total > 0:
                print(f"  {min(100, b * bs * 100 / total):5.1f}%  {time.time()-t0:.0f}s")
        urllib.request.urlretrieve(URL, ZIP, hook)
    print("Extracting train sequences ...")
    with zipfile.ZipFile(ZIP) as z:
        for name in z.namelist():
            parts = name.split("/")
            if "train" not in parts or name.endswith("/"):
                continue
            seq = parts[parts.index("train") + 1]
            rest = parts[parts.index("train") + 2:]
            if rest[:1] == ["img1"]:
                if int(os.path.splitext(rest[1])[0]) > KEEP_FRAMES:
                    continue
            elif rest != ["gt", "gt.txt"]:
                continue
            out = os.path.join(DEST, seq, *rest)
            os.makedirs(os.path.dirname(out), exist_ok=True)
            with z.open(name) as src, open(out, "wb") as dst:
                shutil.copyfileobj(src, dst)
    os.remove(ZIP)                      # free the 5 GB
    print("Done:", sorted(d for d in os.listdir(DEST) if d.startswith("MOT20-")))
for d in sorted(os.listdir(DEST)):
    p = os.path.join(DEST, d, "img1")
    if os.path.isdir(p):
        print(f"  {d}: {len(os.listdir(p))} frames")
